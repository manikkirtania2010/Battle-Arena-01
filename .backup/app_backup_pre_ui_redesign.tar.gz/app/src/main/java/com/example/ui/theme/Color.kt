package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val GamingDarkBackground = Color(0xFF0B0D17)
val GamingSurface = Color(0xFF141824)
val GamingSurfaceVariant = Color(0xFF1F2438)
val GamingBorder = Color(0xFF2B324D)

val GamingPrimary = Color(0xFFFF5722) // Free Fire Fiery Orange
val GamingPrimaryHover = Color(0xFFFF7043)
val GamingPrimaryContainer = Color(0xFF3E1508)
val OnGamingPrimary = Color(0xFFFFFFFF)

val GamingSecondary = Color(0xFF00E5FF) // Electric Cyber Cyan
val GamingSecondaryContainer = Color(0xFF00363D)
val OnGamingSecondary = Color(0xFF001F24)

val GamingGold = Color(0xFFFFD700) // Victory Prize Gold
val GamingGoldContainer = Color(0xFF423500)

val GamingGreen = Color(0xFF00E676) // Success / Live / Deposit
val GamingRed = Color(0xFFFF3D00) // Danger / Loss / Live badge

val TextPrimary = Color(0xFFF3F5FC)
val TextSecondary = Color(0xFFA5ADC4)
val TextMuted = Color(0xFF6F7791)
