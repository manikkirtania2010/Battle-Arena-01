package com.example.model

enum class AppLanguage(val code: String, val displayName: String, val flag: String) {
    ENGLISH("en", "English", "🇺🇸"),
    BENGALI("bn", "বাংলা", "🇧🇩")
}

object AppStrings {
    fun appTitle(lang: AppLanguage) = if (lang == AppLanguage.BENGALI) "ব্যাটেল এরিনা" else "Battle Arena"
    fun freeFireIndia(lang: AppLanguage) = if (lang == AppLanguage.BENGALI) "ফ্রি ফায়ার ইন্ডিয়া টুর্নামেন্ট" else "Free Fire India Esports"
    
    // Bottom Nav
    fun navTournaments(lang: AppLanguage) = if (lang == AppLanguage.BENGALI) "টুর্নামেন্ট" else "Matches"
    fun navWallet(lang: AppLanguage) = if (lang == AppLanguage.BENGALI) "ওয়ালেট" else "Wallet"
    fun navLeaderboard(lang: AppLanguage) = if (lang == AppLanguage.BENGALI) "লিডারবোর্ড" else "Ranks"
    fun navProfile(lang: AppLanguage) = if (lang == AppLanguage.BENGALI) "প্রোফাইল" else "Profile"
    fun navAdmin(lang: AppLanguage) = if (lang == AppLanguage.BENGALI) "অ্যাডমিন" else "Admin"

    // Filters
    fun tabAll(lang: AppLanguage) = if (lang == AppLanguage.BENGALI) "সব ম্যাচ" else "All Matches"
    fun tabUpcoming(lang: AppLanguage) = if (lang == AppLanguage.BENGALI) "আসন্ন" else "Upcoming"
    fun tabLive(lang: AppLanguage) = if (lang == AppLanguage.BENGALI) "লাইভ" else "Live"
    fun tabCompleted(lang: AppLanguage) = if (lang == AppLanguage.BENGALI) "সম্পন্ন" else "Completed"

    // Actions
    fun joinTournament(lang: AppLanguage) = if (lang == AppLanguage.BENGALI) "অংশগ্রহণ করুন" else "Join Match"
    fun joined(lang: AppLanguage) = if (lang == AppLanguage.BENGALI) "যোগদান সম্পন্ন" else "Joined"
    fun matchFull(lang: AppLanguage) = if (lang == AppLanguage.BENGALI) "স্লট পূর্ণ" else "Slots Full"
    fun addMoney(lang: AppLanguage) = if (lang == AppLanguage.BENGALI) "টাকা যোগ করুন" else "Add Money"
    fun withdraw(lang: AppLanguage) = if (lang == AppLanguage.BENGALI) "উইথড্র করুন" else "Withdraw"
    fun referEarn(lang: AppLanguage) = if (lang == AppLanguage.BENGALI) "রেফার ও আয়" else "Refer & Earn"
    fun copyRoom(lang: AppLanguage) = if (lang == AppLanguage.BENGALI) "রুম আইডি কপি" else "Copy Room ID"
    fun copyPass(lang: AppLanguage) = if (lang == AppLanguage.BENGALI) "পাসওয়ার্ড কপি" else "Copy Pass"

    // Wallet
    fun totalBalance(lang: AppLanguage) = if (lang == AppLanguage.BENGALI) "সর্বমোট ব্যালেন্স" else "Total Balance"
    fun depositBalance(lang: AppLanguage) = if (lang == AppLanguage.BENGALI) "ডিপোজিট ক্যাশ" else "Deposit Cash"
    fun winningBalance(lang: AppLanguage) = if (lang == AppLanguage.BENGALI) "উইনিং ক্যাশ" else "Winnings Cash"
    fun bonusBalance(lang: AppLanguage) = if (lang == AppLanguage.BENGALI) "বোনাস ক্যাশ" else "Bonus Cash"
    fun minWithdrawNotice(lang: AppLanguage) = if (lang == AppLanguage.BENGALI) "নূন্যতম উইথড্র অ্যামাউন্ট ₹৫০" else "Minimum withdrawal amount is ₹50"
    fun transactionHistory(lang: AppLanguage) = if (lang == AppLanguage.BENGALI) "লেনদেনের হিস্ট্রি" else "Transaction History"

    // Tournament Details
    fun entryFee(lang: AppLanguage) = if (lang == AppLanguage.BENGALI) "এন্ট্রি ফি" else "Entry Fee"
    fun prizePool(lang: AppLanguage) = if (lang == AppLanguage.BENGALI) "প্রাইজ পুল" else "Prize Pool"
    fun slots(lang: AppLanguage) = if (lang == AppLanguage.BENGALI) "স্লট" else "Slots"
    fun map(lang: AppLanguage) = if (lang == AppLanguage.BENGALI) "ম্যাপ" else "Map"
    fun startTime(lang: AppLanguage) = if (lang == AppLanguage.BENGALI) "শুরুর সময়" else "Start Time"
    fun rules(lang: AppLanguage) = if (lang == AppLanguage.BENGALI) "ম্যাচ নিয়মাবলী" else "Match Rules"
    fun prizeBreakdown(lang: AppLanguage) = if (lang == AppLanguage.BENGALI) "প্রাইজ বণ্টন তালিকা" else "Prize Distribution"
    fun roomDetails(lang: AppLanguage) = if (lang == AppLanguage.BENGALI) "রুম আইডি ও পাসওয়ার্ড" else "Room ID & Password"
    fun roomLockedNotice(lang: AppLanguage) = if (lang == AppLanguage.BENGALI) 
        "🔒 রুম আইডি ও পাসওয়ার্ড ম্যাচ শুরুর ১৫ মিনিট আগে শুধুমাত্র অনুমোদিত অংশগ্রহণকারীদের জন্য উন্মুক্ত হবে।" 
        else "🔒 Room ID & Password will be unlocked 15 minutes before match starts only for joined players."

    // Legal Notice
    fun legalDisclaimer(lang: AppLanguage) = if (lang == AppLanguage.BENGALI)
        "⚠️ তথ্য: এটি একটি স্কিল-বেসড এস্পোর্টস প্ল্যাটফর্ম (১৮+)। অনুমোদিত পেমেন্ট গেটওয়ে সার্টিফিকেশন প্রক্রিয়াধীন থাকায় বর্তমানে অ্যাপটি ডেমো স্যান্ডবক্স মোডে পরিচালিত হচ্ছে।"
        else "⚠️ Notice: Battle Arena is a skill-based esports platform (18+). Operating in compliant Sandbox/Demo mode pending formal payment gateway authorization."

    // Telegram Support & Updates
    fun customerSupport(lang: AppLanguage) = if (lang == AppLanguage.BENGALI) "গ্রাহক সহায়তা" else "Customer Support"
    fun customerSupportDesc(lang: AppLanguage) = if (lang == AppLanguage.BENGALI) "ব্যাটেল এরিনা সাপোর্ট গ্রুপ (টেলিগ্রাম)" else "Battle Arena Support Group (Telegram)"
    fun officialTelegram(lang: AppLanguage) = if (lang == AppLanguage.BENGALI) "অফিসিয়াল টেলিগ্রাম চ্যানেল" else "Official Telegram Channel"
    fun officialTelegramDesc(lang: AppLanguage) = if (lang == AppLanguage.BENGALI) "@BattleArenaOfficial1 • নোটিশ ও রুম আইডি" else "@BattleArenaOfficial1 • Match Notices & Updates"
    fun helpAndSupport(lang: AppLanguage) = if (lang == AppLanguage.BENGALI) "হেল্প ও কাস্টমার সাপোর্ট" else "Help & Customer Support"
}
