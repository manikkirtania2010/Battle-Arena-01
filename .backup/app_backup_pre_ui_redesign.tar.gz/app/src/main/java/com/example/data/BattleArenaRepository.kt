package com.example.data

import com.example.auth.AuthManager
import com.example.model.AddMoneyRequest
import com.example.model.AdminAuditLog
import com.example.model.AdminLedgerEntry
import com.example.model.AdminLedgerEntryType
import com.example.model.AdminWallet
import com.example.model.AdminWithdrawalRecord
import com.example.model.AdminWithdrawalStatus
import com.example.model.AppLanguage
import com.example.model.AppNotification
import com.example.model.BATTLE_ARENA_OWNER_EMAIL
import com.example.model.GameMode
import com.example.model.IncidentReport
import com.example.model.LeaderboardEntry
import com.example.model.LevelVerificationStatus
import com.example.model.MatchRefundItem
import com.example.model.PaymentApprovalStatus
import com.example.model.PlatformCommissionRecord
import com.example.model.PlayerParticipant
import com.example.model.PlayerVerificationStatus
import com.example.model.RoomRosterAuditReport
import com.example.model.BrPrizeTier
import com.example.model.MatchResultRecord
import com.example.model.PrizePaymentStatus
import com.example.model.RefundStatus
import com.example.model.Tournament
import com.example.model.TournamentStatus
import com.example.model.Transaction
import com.example.model.TransactionStatus
import com.example.model.TransactionType
import com.example.model.User
import com.example.model.Wallet
import com.example.model.WithdrawalRequest
import com.example.model.WithdrawalStatus
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class BattleArenaRepository {

    val authRepository = AuthenticationRepository()
    val authManager = AuthManager(authRepository)

    private val _currentLanguage = MutableStateFlow(AppLanguage.ENGLISH)
    val currentLanguage: StateFlow<AppLanguage> = _currentLanguage.asStateFlow()

    // Default Super Admin / Owner profile
    private val _currentUser = MutableStateFlow<User?>(
        User(
            id = "BA-70912",
            name = "Manik Hunter",
            email = BATTLE_ARENA_OWNER_EMAIL,
            freeFireName = "⚡MANIK_BOSS⚡",
            freeFireUid = "2948109382",
            freeFireLevel = 45, // Level 45 (Eligible: >= 10)
            phone = "+91 98765 43210",
            avatarId = 1,
            referralCode = "ARENA99",
            totalKills = 48,
            totalWins = 12,
            totalEarnings = 540,
            totalTournaments = 19,
            isAdmin = true
        )
    )
    val currentUser: StateFlow<User?> = _currentUser.asStateFlow()

    private val _currentWallet = MutableStateFlow(
        Wallet(
            userId = "BA-70912",
            depositBalance = 60,
            winningBalance = 40,
            bonusBalance = 15
        )
    )
    val currentWallet: StateFlow<Wallet> = _currentWallet.asStateFlow()

    private val _tournaments = MutableStateFlow<List<Tournament>>(emptyList())
    val tournaments: StateFlow<List<Tournament>> = _tournaments.asStateFlow()

    private val _transactions = MutableStateFlow<List<Transaction>>(emptyList())
    val transactions: StateFlow<List<Transaction>> = _transactions.asStateFlow()

    private val _withdrawals = MutableStateFlow<List<WithdrawalRequest>>(emptyList())
    val withdrawals: StateFlow<List<WithdrawalRequest>> = _withdrawals.asStateFlow()

    private val _addMoneyRequests = MutableStateFlow<List<AddMoneyRequest>>(emptyList())
    val addMoneyRequests: StateFlow<List<AddMoneyRequest>> = _addMoneyRequests.asStateFlow()

    private val _commissions = MutableStateFlow<List<PlatformCommissionRecord>>(emptyList())
    val commissions: StateFlow<List<PlatformCommissionRecord>> = _commissions.asStateFlow()

    private val _leaderboard = MutableStateFlow<List<LeaderboardEntry>>(emptyList())
    val leaderboard: StateFlow<List<LeaderboardEntry>> = _leaderboard.asStateFlow()

    private val _notifications = MutableStateFlow<List<AppNotification>>(emptyList())
    val notifications: StateFlow<List<AppNotification>> = _notifications.asStateFlow()

    private val _incidentReports = MutableStateFlow<List<IncidentReport>>(emptyList())
    val incidentReports: StateFlow<List<IncidentReport>> = _incidentReports.asStateFlow()

    private val _refundRecords = MutableStateFlow<List<MatchRefundItem>>(emptyList())
    val refundRecords: StateFlow<List<MatchRefundItem>> = _refundRecords.asStateFlow()

    private val _adminAuditLogs = MutableStateFlow<List<AdminAuditLog>>(emptyList())
    val adminAuditLogs: StateFlow<List<AdminAuditLog>> = _adminAuditLogs.asStateFlow()

    private val _adminWallet = MutableStateFlow(
        AdminWallet(
            availableBalance = 280,
            reservedBalance = 0,
            totalMatchEarnings = 280,
            totalPrizePaid = 730,
            totalRefundsPaid = 0,
            totalWithdrawalsPaid = 0,
            verifiedUpiId = "kirtaniamanik@okhdfcbank",
            isUpiVerified = true
        )
    )
    val adminWallet: StateFlow<AdminWallet> = _adminWallet.asStateFlow()

    private val _adminWithdrawals = MutableStateFlow<List<AdminWithdrawalRecord>>(emptyList())
    val adminWithdrawals: StateFlow<List<AdminWithdrawalRecord>> = _adminWithdrawals.asStateFlow()

    private val _adminLedger = MutableStateFlow<List<AdminLedgerEntry>>(emptyList())
    val adminLedger: StateFlow<List<AdminLedgerEntry>> = _adminLedger.asStateFlow()

    private val _matchResults = MutableStateFlow<List<MatchResultRecord>>(emptyList())
    val matchResults: StateFlow<List<MatchResultRecord>> = _matchResults.asStateFlow()

    private val processedPaymentTxIds = mutableSetOf<String>()

    fun logAdminAction(action: String, targetId: String, details: String) {
        val performer = _currentUser.value?.email ?: BATTLE_ARENA_OWNER_EMAIL
        val log = AdminAuditLog(
            id = "LOG-${System.currentTimeMillis()}-${(100..999).random()}",
            action = action,
            targetId = targetId,
            details = details,
            performedBy = performer,
            timestamp = System.currentTimeMillis()
        )
        _adminAuditLogs.value = listOf(log) + _adminAuditLogs.value
    }

    init {
        seedInitialData()
    }

    fun toggleLanguage() {
        _currentLanguage.value = if (_currentLanguage.value == AppLanguage.ENGLISH) {
            AppLanguage.BENGALI
        } else {
            AppLanguage.ENGLISH
        }
    }

    fun setLanguage(lang: AppLanguage) {
        _currentLanguage.value = lang
    }

    fun updateProfile(name: String, ffName: String, ffUid: String, phone: String, avatarId: Int) {
        val user = _currentUser.value ?: return
        _currentUser.value = user.copy(
            displayName = name,
            freeFireName = ffName,
            freeFireUID = ffUid,
            phone = phone,
            avatarId = avatarId
        )
    }

    fun submitLevelVerification(level: Int, screenshotNote: String = "ID Level Proof Attached"): Pair<Boolean, String> {
        val user = _currentUser.value ?: return Pair(false, "Not logged in")
        val status = if (level >= 10) LevelVerificationStatus.VERIFIED else LevelVerificationStatus.PENDING
        _currentUser.value = user.copy(
            freeFireLevel = level,
            levelVerificationStatus = status
        )
        addNotification(
            titleEn = "Free Fire Level Updated: Level $level",
            titleBn = "ফ্রি ফায়ার লেভেল আপডেট: লেভেল $level",
            messageEn = if (level >= 10) "Eligible for tournaments (Level 10+ confirmed)." else "Pending owner approval. (Level 10+ required)",
            messageBn = if (level >= 10) "টুর্নামেন্টে অংশগ্রহণের যোগ্য (লেভেল ১০+ নিশ্চিত)।" else "লেভেল ১০+ না হওয়া পর্যন্ত টুর্নামেন্টে খেলা যাবে না।"
        )
        return Pair(true, "Level $level recorded successfully!")
    }

    fun setCurrentUser(user: User?) {
        _currentUser.value = user
    }

    fun signOut() {
        authManager.signOut()
        _currentUser.value = null
    }

    // ==========================================
    // NOTIFICATIONS
    // ==========================================

    fun addNotification(titleEn: String, titleBn: String, messageEn: String, messageBn: String, type: String = "GENERAL") {
        val notif = AppNotification(
            id = "NOTIF-${System.currentTimeMillis()}-${(10..99).random()}",
            titleEn = titleEn,
            titleBn = titleBn,
            messageEn = messageEn,
            messageBn = messageBn,
            type = type
        )
        _notifications.value = listOf(notif) + _notifications.value
    }

    fun markNotificationRead(id: String) {
        _notifications.value = _notifications.value.map {
            if (it.id == id) it.copy(isRead = true) else it
        }
    }

    // ==========================================
    // ADD MONEY — MANUAL OWNER VERIFICATION
    // ==========================================

    fun submitAddMoneyRequest(
        amount: Int,
        paymentMethod: String,
        utrNumber: String,
        screenshotNote: String = "Screenshot Submitted"
    ): Pair<Boolean, String> {
        val user = _currentUser.value ?: return Pair(false, "Please log in")

        if (amount < 20) {
            return Pair(false, "Minimum Add Money amount is ₹20 / নূন্যতম ডিপোজিট অ্যামাউন্ট ₹২০")
        }

        val cleanUtr = utrNumber.trim().uppercase()
        if (cleanUtr.length < 6) {
            return Pair(false, "Please enter a valid 12-digit UTR or Transaction ID / সঠিক UTR বা Transaction ID দিন")
        }

        // Idempotency: Prevent duplicate submissions or already credited UTRs
        if (processedPaymentTxIds.contains(cleanUtr) ||
            _addMoneyRequests.value.any { it.utrNumber.equals(cleanUtr, ignoreCase = true) && it.status != PaymentApprovalStatus.REJECTED }
        ) {
            return Pair(false, "This Transaction ID / UTR has already been submitted or credited! / এই UTR ইতিমধ্যে ব্যবহার করা হয়েছে")
        }

        val reqId = "DEP-" + (1000 + _addMoneyRequests.value.size + 1)
        val request = AddMoneyRequest(
            id = reqId,
            userId = user.id,
            userName = user.name,
            freeFireUid = user.freeFireUid,
            amount = amount,
            paymentMethod = paymentMethod,
            utrNumber = cleanUtr,
            screenshotNote = screenshotNote,
            status = PaymentApprovalStatus.PENDING,
            requestedAt = System.currentTimeMillis()
        )
        _addMoneyRequests.value = listOf(request) + _addMoneyRequests.value

        val tx = Transaction(
            id = reqId,
            userId = user.id,
            type = TransactionType.ADD_MONEY,
            amount = amount,
            status = TransactionStatus.PENDING,
            timestamp = System.currentTimeMillis(),
            referenceId = cleanUtr,
            titleEn = "Deposit: ₹$amount via $paymentMethod",
            titleBn = "ডিপোজিট: ₹$amount ($paymentMethod)",
            subtitleEn = "UTR: $cleanUtr • Status: Pending Owner Verification",
            subtitleBn = "ইউটিআর: $cleanUtr • স্ট্যাটাস: মালিকের ভেরিফিকেশন পেন্ডিং"
        )
        _transactions.value = listOf(tx) + _transactions.value

        addNotification(
            titleEn = "Deposit Request Submitted",
            titleBn = "ডিপোজিট অনুরোধ জমা হয়েছে",
            messageEn = "₹$amount (UTR: $cleanUtr) is under review. Owner will verify receipt before crediting your wallet.",
            messageBn = "₹$amount (ইউটিআর: $cleanUtr) রিভিউতে আছে। মালিক ভেরিফাই করার পর ওয়ালেটে ক্রেডিট হবে।",
            type = "PAYMENT"
        )

        return Pair(true, "Add Money request submitted! Owner will verify your payment UTR.")
    }

    fun approveAddMoneyRequest(requestId: String): Pair<Boolean, String> {
        val req = _addMoneyRequests.value.find { it.id == requestId } 
            ?: return Pair(false, "Request not found")

        if (req.status != PaymentApprovalStatus.PENDING) {
            return Pair(false, "Request is already ${req.status.name}")
        }

        // Record UTR to prevent duplicate re-use
        processedPaymentTxIds.add(req.utrNumber)

        // Update request status
        _addMoneyRequests.value = _addMoneyRequests.value.map {
            if (it.id == requestId) it.copy(status = PaymentApprovalStatus.APPROVED) else it
        }

        // Credit wallet if it belongs to current active user
        if (_currentUser.value?.id == req.userId) {
            val wallet = _currentWallet.value
            _currentWallet.value = wallet.copy(depositBalance = wallet.depositBalance + req.amount)
        }

        // Update corresponding transaction status to SUCCESS
        _transactions.value = _transactions.value.map { tx ->
            if (tx.id == requestId || tx.referenceId == req.utrNumber) {
                tx.copy(
                    status = TransactionStatus.SUCCESS,
                    subtitleEn = "UTR: ${req.utrNumber} • Verified & Credited",
                    subtitleBn = "ইউটিআর: ${req.utrNumber} • ভেরিফায়েড এবং জমা হয়েছে"
                )
            } else tx
        }

        addNotification(
            titleEn = "Deposit Approved: ₹${req.amount}",
            titleBn = "ডিপোজিট অনুমোদিত: ₹${req.amount}",
            messageEn = "Payment UTR ${req.utrNumber} verified by owner. ₹${req.amount} added to your Deposit Cash.",
            messageBn = "পেমেন্ট ইউটিআর ${req.utrNumber} মালিক কর্তৃক ভেরিফাই হয়েছে। ₹${req.amount} ওয়ালেটে যোগ হয়েছে।",
            type = "PAYMENT"
        )

        return Pair(true, "Payment request $requestId approved. ₹${req.amount} credited!")
    }

    fun rejectAddMoneyRequest(requestId: String, reason: String): Pair<Boolean, String> {
        val req = _addMoneyRequests.value.find { it.id == requestId } 
            ?: return Pair(false, "Request not found")

        if (req.status != PaymentApprovalStatus.PENDING) {
            return Pair(false, "Request is already ${req.status.name}")
        }

        _addMoneyRequests.value = _addMoneyRequests.value.map {
            if (it.id == requestId) it.copy(status = PaymentApprovalStatus.REJECTED, rejectionReason = reason) else it
        }

        _transactions.value = _transactions.value.map { tx ->
            if (tx.id == requestId || tx.referenceId == req.utrNumber) {
                tx.copy(
                    status = TransactionStatus.FAILED,
                    subtitleEn = "Rejected by Owner: $reason",
                    subtitleBn = "মালিক কর্তৃক প্রত্যাখ্যাত: $reason"
                )
            } else tx
        }

        addNotification(
            titleEn = "Deposit Rejected",
            titleBn = "ডিপোজিট প্রত্যাখ্যাত হয়েছে",
            messageEn = "Deposit of ₹${req.amount} was rejected: $reason",
            messageBn = "₹${req.amount} ডিপোজিট প্রত্যাখ্যাত: $reason",
            type = "PAYMENT"
        )

        return Pair(true, "Payment request $requestId rejected.")
    }

    // ==========================================
    // VIRTUAL PRIZE WALLET & MANUAL REAL MONEY WITHDRAWALS
    // ==========================================

    fun requestWithdrawal(amount: Int, method: String, destination: String): Pair<Boolean, String> {
        val user = _currentUser.value ?: return Pair(false, "User not found")
        val wallet = _currentWallet.value

        if (amount < 50) {
            return Pair(false, "Minimum withdrawal is ₹50 / নূন্যতম উইথড্র অ্যামাউন্ট ₹৫০")
        }
        val cleanDest = destination.trim()
        if (cleanDest.length < 5 || !cleanDest.contains("@")) {
            return Pair(false, "Please enter a valid UPI ID (e.g. mobile@upi, name@okhdfcbank)")
        }
        // Prevent duplicate spamming while another withdrawal is pending review
        val hasActiveWithdrawal = _withdrawals.value.any {
            it.userId == user.id && (it.status == WithdrawalStatus.PENDING || it.status == WithdrawalStatus.APPROVED || it.status == WithdrawalStatus.PROCESSING)
        }
        if (hasActiveWithdrawal) {
            return Pair(false, "You already have an active withdrawal request under review! / আপনার একটি উইথড্রয়াল অনুরোধ ইতিমধ্যে পেন্ডিং রয়েছে")
        }

        if (wallet.winningBalance < amount) {
            return Pair(false, "Insufficient Winning balance / অপর্যাপ্ত উইনিং ব্যালেন্স (Deposit balance cannot be withdrawn directly)")
        }

        // Reserve virtual funds: deduct from available winningBalance and add to reservedBalance
        _currentWallet.value = wallet.copy(
            winningBalance = wallet.winningBalance - amount,
            reservedBalance = wallet.reservedBalance + amount
        )

        val reqId = "WTH-" + (1000 + _withdrawals.value.size + 1)
        val req = WithdrawalRequest(
            id = reqId,
            userId = user.id,
            userName = user.name,
            freeFireUid = user.freeFireUid,
            amount = amount,
            method = "UPI",
            payoutDestination = cleanDest,
            status = WithdrawalStatus.PENDING,
            requestedAt = System.currentTimeMillis()
        )
        _withdrawals.value = listOf(req) + _withdrawals.value

        val tx = Transaction(
            id = reqId,
            userId = user.id,
            type = TransactionType.WITHDRAWAL,
            amount = amount,
            status = TransactionStatus.PENDING,
            timestamp = System.currentTimeMillis(),
            referenceId = reqId,
            titleEn = "Withdrawal to $cleanDest",
            titleBn = "$cleanDest এ উইথড্রয়াল",
            subtitleEn = "Status: Pending Owner Approval (₹$amount Reserved)",
            subtitleBn = "স্ট্যাটাস: মালিকের অনুমোদনের অপেক্ষায় (₹$amount সংরক্ষিত)"
        )
        _transactions.value = listOf(tx) + _transactions.value

        addNotification(
            titleEn = "Withdrawal Request Submitted (#$reqId)",
            titleBn = "উইথড্রয়াল অনুরোধ জমা হয়েছে (#$reqId)",
            messageEn = "₹$amount to $cleanDest is pending Admin review. Real money will be manually transferred to your UPI ID upon Owner approval.",
            messageBn = "₹$amount উইথড্র অনুরোধ অ্যাডমিন পর্যালোচনার অপেক্ষায়। অনুমোদনের পর মালিক সরাসরি ইউপিআই-তে রিয়েল মানি ট্রান্সফার করবেন।",
            type = "WITHDRAWAL"
        )

        logAdminAction(
            action = "WITHDRAWAL_REQUESTED",
            targetId = reqId,
            details = "Player ${user.name} (UID: ${user.freeFireUid}) requested ₹$amount to $cleanDest"
        )

        return Pair(true, "Withdrawal request submitted! ₹$amount reserved from your winning balance pending Owner transfer.")
    }

    fun approveWithdrawal(requestId: String): Pair<Boolean, String> {
        val currentUser = _currentUser.value ?: return Pair(false, "Authentication required")
        if (!currentUser.isOwner) {
            return Pair(false, "Security violation: Only verified App Owner can manage withdrawal requests.")
        }

        val req = _withdrawals.value.find { it.id == requestId }
            ?: return Pair(false, "Withdrawal request not found")

        if (req.status != WithdrawalStatus.PENDING) {
            return Pair(false, "Request is already ${req.status.name}")
        }

        _withdrawals.value = _withdrawals.value.map {
            if (it.id == requestId) it.copy(status = WithdrawalStatus.APPROVED, adminNotes = "Approved by Owner. Ready for manual real-money payout.") else it
        }

        _transactions.value = _transactions.value.map { tx ->
            if (tx.id == requestId) {
                tx.copy(
                    subtitleEn = "Status: Approved by Owner • Manual UPI transfer in progress",
                    subtitleBn = "স্ট্যাটাস: অনুমোদিত • ম্যানুয়াল ইউপিআই ট্রান্সফার চলছে"
                )
            } else tx
        }

        addNotification(
            titleEn = "Withdrawal Approved (#$requestId)",
            titleBn = "উইথড্রয়াল অনুমোদিত (#$requestId)",
            messageEn = "Your withdrawal of ₹${req.amount} has been approved by Owner. Real money manual UPI transfer is being processed.",
            messageBn = "আপনার ₹${req.amount} উইথড্রয়াল অনুমোদিত হয়েছে। রিয়েল মানি ট্রান্সফার প্রক্রিয়াধীন রয়েছে।",
            type = "WITHDRAWAL"
        )

        logAdminAction(
            action = "WITHDRAWAL_APPROVED",
            targetId = requestId,
            details = "Owner approved withdrawal #$requestId (₹${req.amount} to ${req.payoutDestination})"
        )

        return Pair(true, "Withdrawal #$requestId approved. Please manually send ₹${req.amount} to ${req.payoutDestination}.")
    }

    fun markWithdrawalPaid(requestId: String, paymentUtr: String): Pair<Boolean, String> {
        val currentUser = _currentUser.value ?: return Pair(false, "Authentication required")
        if (!currentUser.isOwner) {
            return Pair(false, "Security violation: Only verified App Owner can authorize and record payouts.")
        }

        val req = _withdrawals.value.find { it.id == requestId }
            ?: return Pair(false, "Withdrawal request not found")

        if (req.status == WithdrawalStatus.PAID) {
            return Pair(false, "Duplicate payment prevented: Request #$requestId has already been marked as Paid.")
        }
        if (req.status == WithdrawalStatus.REJECTED || req.status == WithdrawalStatus.FAILED) {
            return Pair(false, "Cannot pay a rejected or failed withdrawal request.")
        }

        val cleanUtr = paymentUtr.trim().uppercase()
        if (cleanUtr.length < 6) {
            return Pair(false, "Please provide a valid bank UTR / Payment reference (minimum 6 characters).")
        }

        // Prevent duplicate UTR usage across all payouts
        if (processedPaymentTxIds.contains(cleanUtr)) {
            return Pair(false, "Duplicate payout blocked: UTR $cleanUtr has already been recorded for another payout!")
        }
        processedPaymentTxIds.add(cleanUtr)

        val now = System.currentTimeMillis()

        // 1. Update Withdrawal Request
        _withdrawals.value = _withdrawals.value.map {
            if (it.id == requestId) {
                it.copy(
                    status = WithdrawalStatus.PAID,
                    paymentReference = cleanUtr,
                    processedAt = now,
                    adminNotes = "Real money transferred manually via UPI by Owner."
                )
            } else it
        }

        // 2. Permanently deduct reserved virtual balance
        if (req.userId == _currentUser.value?.id) {
            val wallet = _currentWallet.value
            _currentWallet.value = wallet.copy(
                reservedBalance = (wallet.reservedBalance - req.amount).coerceAtLeast(0)
            )
        }

        // 3. Mark user transaction as SUCCESS
        _transactions.value = _transactions.value.map { tx ->
            if (tx.id == requestId) {
                tx.copy(
                    status = TransactionStatus.SUCCESS,
                    referenceId = cleanUtr,
                    subtitleEn = "Paid to ${req.payoutDestination} • Bank UTR: $cleanUtr",
                    subtitleBn = "${req.payoutDestination} এ সফলভাবে পেইড • ব্যাংক ইউটিআর: $cleanUtr"
                )
            } else tx
        }

        // 4. Update Admin Wallet accounting
        _adminWallet.value = _adminWallet.value.copy(
            totalPrizePaid = _adminWallet.value.totalPrizePaid + req.amount
        )
        val payoutLedgerEntry = AdminLedgerEntry(
            id = "LED-${System.currentTimeMillis()}",
            type = AdminLedgerEntryType.PRIZE_PAYOUT,
            amount = req.amount,
            descriptionEn = "Manual real money withdrawal paid to ${req.payoutDestination} (UTR: $cleanUtr)",
            descriptionBn = "${req.payoutDestination} এ ম্যানুয়াল ইউপিআই উইথড্রয়াল পেইড (ইউটিআর: $cleanUtr)",
            referenceId = cleanUtr,
            timestamp = now
        )
        _adminLedger.value = listOf(payoutLedgerEntry) + _adminLedger.value

        // 5. Notify player
        addNotification(
            titleEn = "Withdrawal Paid! (#$requestId)",
            titleBn = "উইথড্রয়াল সফলভাবে সম্পন্ন! (#$requestId)",
            messageEn = "₹${req.amount} has been transferred to your UPI ID ${req.payoutDestination}. Bank UTR: $cleanUtr.",
            messageBn = "₹${req.amount} আপনার ইউপিআই ${req.payoutDestination} তে পাঠানো হয়েছে। ব্যাংক ইউটিআর: $cleanUtr।",
            type = "PAYMENT"
        )

        logAdminAction(
            action = "WITHDRAWAL_PAID",
            targetId = requestId,
            details = "Owner marked withdrawal #$requestId as PAID (₹${req.amount} to ${req.payoutDestination}, UTR: $cleanUtr)"
        )

        return Pair(true, "Withdrawal marked as Paid! Bank UTR: $cleanUtr recorded successfully.")
    }

    fun rejectWithdrawal(requestId: String, reason: String): Pair<Boolean, String> {
        val currentUser = _currentUser.value ?: return Pair(false, "Authentication required")
        if (!currentUser.isOwner) {
            return Pair(false, "Security violation: Only verified App Owner can reject withdrawals.")
        }

        val req = _withdrawals.value.find { it.id == requestId }
            ?: return Pair(false, "Withdrawal request not found")

        if (req.status == WithdrawalStatus.PAID) {
            return Pair(false, "Cannot reject an already paid withdrawal.")
        }
        if (req.status == WithdrawalStatus.REJECTED) {
            return Pair(false, "Request is already rejected.")
        }

        val cleanReason = reason.ifBlank { "Declined by Admin" }
        val now = System.currentTimeMillis()

        // 1. Update Withdrawal Request
        _withdrawals.value = _withdrawals.value.map {
            if (it.id == requestId) {
                it.copy(
                    status = WithdrawalStatus.REJECTED,
                    rejectionReason = cleanReason,
                    processedAt = now
                )
            } else it
        }

        // 2. Release reserved virtual funds back to player's winning balance
        if (req.userId == _currentUser.value?.id) {
            val wallet = _currentWallet.value
            _currentWallet.value = wallet.copy(
                winningBalance = wallet.winningBalance + req.amount,
                reservedBalance = (wallet.reservedBalance - req.amount).coerceAtLeast(0)
            )
        }

        // 3. Mark transaction as FAILED
        _transactions.value = _transactions.value.map { tx ->
            if (tx.id == requestId) {
                tx.copy(
                    status = TransactionStatus.FAILED,
                    subtitleEn = "Rejected: $cleanReason • ₹${req.amount} refunded to Winning Balance",
                    subtitleBn = "বাতিল: $cleanReason • ₹${req.amount} উইনিং ব্যালেন্সে রিফান্ড"
                )
            } else tx
        }

        // 4. Notify player
        addNotification(
            titleEn = "Withdrawal Rejected (#$requestId)",
            titleBn = "উইথড্রয়াল বাতিল (#$requestId)",
            messageEn = "Your withdrawal of ₹${req.amount} was rejected: $cleanReason. Reserved amount has been released back to your Winning Balance.",
            messageBn = "আপনার ₹${req.amount} উইথড্রয়াল বাতিল হয়েছে: $cleanReason। টাকা উইনিং ব্যালেন্সে ফেরত দেওয়া হয়েছে।",
            type = "WITHDRAWAL"
        )

        logAdminAction(
            action = "WITHDRAWAL_REJECTED",
            targetId = requestId,
            details = "Owner rejected withdrawal #$requestId (Reason: $cleanReason, ₹${req.amount} refunded to player)"
        )

        return Pair(true, "Withdrawal #$requestId rejected and ₹${req.amount} refunded to player wallet.")
    }

    fun failWithdrawal(requestId: String, reason: String): Pair<Boolean, String> {
        val currentUser = _currentUser.value ?: return Pair(false, "Authentication required")
        if (!currentUser.isOwner) {
            return Pair(false, "Security violation: Only verified App Owner can manage withdrawals.")
        }

        val req = _withdrawals.value.find { it.id == requestId }
            ?: return Pair(false, "Withdrawal request not found")

        if (req.status == WithdrawalStatus.PAID) {
            return Pair(false, "Cannot fail an already paid withdrawal.")
        }

        val cleanReason = reason.ifBlank { "Payment provider network error" }
        val now = System.currentTimeMillis()

        _withdrawals.value = _withdrawals.value.map {
            if (it.id == requestId) {
                it.copy(
                    status = WithdrawalStatus.FAILED,
                    rejectionReason = cleanReason,
                    processedAt = now
                )
            } else it
        }

        // Release reserved funds back to player's winning balance
        if (req.userId == _currentUser.value?.id) {
            val wallet = _currentWallet.value
            _currentWallet.value = wallet.copy(
                winningBalance = wallet.winningBalance + req.amount,
                reservedBalance = (wallet.reservedBalance - req.amount).coerceAtLeast(0)
            )
        }

        _transactions.value = _transactions.value.map { tx ->
            if (tx.id == requestId) {
                tx.copy(
                    status = TransactionStatus.FAILED,
                    subtitleEn = "Payment Failed: $cleanReason • ₹${req.amount} refunded to Winning Balance",
                    subtitleBn = "পেমেন্ট ব্যর্থ: $cleanReason • ₹${req.amount} উইনিং ব্যালেন্সে রিফান্ড"
                )
            } else tx
        }

        addNotification(
            titleEn = "Withdrawal Payment Failed (#$requestId)",
            titleBn = "উইথড্রয়াল পেমেন্ট ব্যর্থ (#$requestId)",
            messageEn = "Bank transfer failed: $cleanReason. ₹${req.amount} has been restored to your Winning Balance.",
            messageBn = "ব্যাংক ট্রান্সফার ব্যর্থ: $cleanReason। ₹${req.amount} উইনিং ব্যালেন্সে রিফান্ড হয়েছে।",
            type = "WITHDRAWAL"
        )

        logAdminAction(
            action = "WITHDRAWAL_FAILED",
            targetId = requestId,
            details = "Withdrawal #$requestId payment failed (Reason: $cleanReason, funds released to player)"
        )

        return Pair(true, "Withdrawal #$requestId marked as Failed. Funds restored to player wallet.")
    }

    fun updateWithdrawalStatus(requestId: String, newStatus: WithdrawalStatus, reason: String? = null): Pair<Boolean, String> {
        return when (newStatus) {
            WithdrawalStatus.APPROVED -> approveWithdrawal(requestId)
            WithdrawalStatus.PROCESSING -> {
                val currentUser = _currentUser.value ?: return Pair(false, "Authentication required")
                if (!currentUser.isOwner) return Pair(false, "Owner authorization required")
                _withdrawals.value = _withdrawals.value.map {
                    if (it.id == requestId) it.copy(status = WithdrawalStatus.PROCESSING) else it
                }
                _transactions.value = _transactions.value.map {
                    if (it.id == requestId) it.copy(subtitleEn = "Status: Processing Manual UPI Payout") else it
                }
                Pair(true, "Withdrawal $requestId marked as Processing")
            }
            WithdrawalStatus.PAID -> markWithdrawalPaid(requestId, reason ?: ("UTR" + System.currentTimeMillis()))
            WithdrawalStatus.REJECTED -> rejectWithdrawal(requestId, reason ?: "Declined by Admin")
            WithdrawalStatus.FAILED -> failWithdrawal(requestId, reason ?: "Payment Failed")
            WithdrawalStatus.PENDING -> Pair(false, "Cannot reset status to Pending")
        }
    }

    // ==========================================
    // TOURNAMENT JOIN & ELIGIBILITY ENFORCEMENT
    // ==========================================

    fun joinTournament(tournamentId: String): Pair<Boolean, String> {
        val user = _currentUser.value ?: return Pair(false, "Please log in")

        // 1. Strict Hack/Ban Check
        if (user.isBanned) {
            return Pair(false, "Your account has been banned for Fair Play violation: ${user.banReason ?: "Fair Play violation"}")
        }

        // 2. Strict Free Fire Level 10 Eligibility Check
        if (user.freeFireLevel < 10) {
            return Pair(false, "Free Fire Account Level 10 or above is strictly required! (Your level: ${user.freeFireLevel}) / টুর্নামেন্টে অংশগ্রহণের জন্য ফ্রি ফায়ার অ্যাকাউন্টের লেভেল ১০ বা তার বেশি হতে হবে")
        }

        if (user.levelVerificationStatus == LevelVerificationStatus.REJECTED) {
            return Pair(false, "Free Fire Level verification was rejected. Please re-submit account level proof in Profile.")
        }

        val tournament = _tournaments.value.find { it.id == tournamentId } 
            ?: return Pair(false, "Tournament not found")

        if (tournament.isFull) {
            return Pair(false, "Tournament is full / টুর্নামেন্টের স্লট পূর্ণ")
        }
        if (tournament.isUserJoined(user.id)) {
            return Pair(false, "Already joined this tournament / ইতিমধ্যে জয়েন করেছেন")
        }
        // Prevent duplicate registration with the same Free Fire UID
        if (tournament.isFreeFireUidRegistered(user.freeFireUid)) {
            return Pair(false, "Free Fire UID (${user.freeFireUid}) is already registered in this match! / এই ফ্রি ফায়ার UID ইতিমধ্যে এই ম্যাচে রেজিস্টার্ড")
        }

        val fee = tournament.entryFee
        val wallet = _currentWallet.value
        if (wallet.totalBalance < fee) {
            return Pair(false, "Insufficient balance! Please Add Money first (₹$fee needed) / অপর্যাপ্ত ব্যালেন্স, টাকা যোগ করুন")
        }

        // Deduct fee: up to 20% from bonus, then deposit, then winning
        var remainingFee = fee
        var newBonus = wallet.bonusBalance
        var newDeposit = wallet.depositBalance
        var newWinning = wallet.winningBalance

        val maxBonusUsable = (fee * 0.20).toInt()
        val bonusToDeduct = minOf(newBonus, maxBonusUsable)
        newBonus -= bonusToDeduct
        remainingFee -= bonusToDeduct

        val depositToDeduct = minOf(newDeposit, remainingFee)
        newDeposit -= depositToDeduct
        remainingFee -= depositToDeduct

        if (remainingFee > 0) {
            newWinning -= remainingFee
        }

        _currentWallet.value = wallet.copy(
            depositBalance = newDeposit,
            winningBalance = newWinning,
            bonusBalance = newBonus
        )

        // Assign team if Clash Squad
        val team = if (tournament.mode == GameMode.CLASH_SQUAD) {
            if (tournament.participants.count { it.team == "Team A" } < 4) "Team A" else "Team B"
        } else null

        // Generate unique Entry ID bound to user, FF UID, and tournament
        val modeCode = when (tournament.mode) {
            GameMode.LONE_WOLF -> "LW"
            GameMode.CLASH_SQUAD -> "CS"
            GameMode.BATTLE_ROYALE -> "BR"
        }
        val cleanTourney = tournament.id.replace("T-", "")
        val cleanUid = user.freeFireUid.takeLast(4)
        val randomToken = UUID.randomUUID().toString().take(4).uppercase()
        val uniqueEntryId = "BA-ENTRY-$modeCode-$cleanTourney-$cleanUid-$randomToken"

        val participant = PlayerParticipant(
            userId = user.id,
            name = user.name,
            freeFireName = user.freeFireName,
            freeFireUid = user.freeFireUid,
            entryId = uniqueEntryId,
            registeredAt = System.currentTimeMillis(),
            team = team,
            isPaid = true,
            entryFeePaid = fee,
            verificationStatus = PlayerVerificationStatus.VERIFIED
        )

        val updatedParticipants = tournament.participants + participant
        var newStatus = tournament.status
        var countdownStart: Long? = tournament.countdownStartMillis
        var waitingAt: Long? = tournament.waitingPlayerJoinedAt

        var shouldAutoCreateNext = false
        var notifyCountdown = false

        when (tournament.mode) {
            GameMode.LONE_WOLF -> {
                if (updatedParticipants.size == 1) {
                    newStatus = TournamentStatus.MATCHMAKING
                    waitingAt = System.currentTimeMillis()
                    countdownStart = null // Countdown must NOT start until second player joins
                } else if (updatedParticipants.size >= 2) {
                    newStatus = TournamentStatus.CONFIRMED
                    countdownStart = System.currentTimeMillis()
                    notifyCountdown = true
                    shouldAutoCreateNext = true
                }
            }
            GameMode.CLASH_SQUAD -> {
                if (updatedParticipants.size >= 8) {
                    newStatus = TournamentStatus.CONFIRMED
                    countdownStart = System.currentTimeMillis()
                    notifyCountdown = true
                    shouldAutoCreateNext = true
                }
            }
            GameMode.BATTLE_ROYALE -> {
                if (updatedParticipants.size >= 40) {
                    newStatus = TournamentStatus.CONFIRMED
                }
            }
        }

        _tournaments.value = _tournaments.value.map { t ->
            if (t.id == tournamentId) {
                t.copy(
                    participants = updatedParticipants,
                    status = newStatus,
                    countdownStartMillis = countdownStart,
                    waitingPlayerJoinedAt = waitingAt
                )
            } else t
        }

        val tx = Transaction(
            id = uniqueEntryId,
            userId = user.id,
            type = TransactionType.ENTRY_FEE,
            amount = fee,
            status = TransactionStatus.SUCCESS,
            timestamp = System.currentTimeMillis(),
            referenceId = tournament.id,
            titleEn = "Entry Fee: ${tournament.titleEn}",
            titleBn = "এন্ট্রি ফি: ${tournament.titleBn}",
            subtitleEn = "Entry ID: $uniqueEntryId • Mode: ${tournament.mode.tagEn} • Fee ₹$fee (Bound to FF: ${user.freeFireUid})",
            subtitleBn = "এন্ট্রি আইডি: $uniqueEntryId • মোড: ${tournament.mode.tagBn} • ফি ₹$fee"
        )
        _transactions.value = listOf(tx) + _transactions.value

        addNotification(
            titleEn = "Registered for ${tournament.titleEn}",
            titleBn = "${tournament.titleBn} তে যোগ দিয়েছেন",
            messageEn = "Entry ID: $uniqueEntryId generated. Entry fee ₹$fee deducted. Room ID & Password will unlock 15 mins before match starts.",
            messageBn = "এন্ট্রি আইডি: $uniqueEntryId তৈরি হয়েছে। ফি ₹$fee কাটা হয়েছে। রুম আইডি ও পাসওয়ার্ড ম্যাচ শুরুর ১৫ মিনিট আগে আনলক হবে।",
            type = "MATCH"
        )

        // When match reaches required player count, notify both players with 45s warning
        if (notifyCountdown) {
            addNotification(
                titleEn = "Your Match Will Start in 45 Seconds!",
                titleBn = "আপনার ম্যাচ ৪৫ সেকেন্ডের মধ্যে শুরু হবে!",
                messageEn = "Your Match Will Start in 45 Seconds! All slots confirmed. Synchronized 45-second countdown started. Get ready in Free Fire!",
                messageBn = "আপনার ম্যাচ ৪৫ সেকেন্ডের মধ্যে শুরু হবে! সকল স্লট পূর্ণ হয়েছে। ৪৫ সেকেন্ডের কাউন্টডাউন শুরু হয়েছে। ফ্রি ফায়ারে প্রস্তুত হন!",
                type = "MATCH"
            )
            logAdminAction("MATCH_CONFIRMED", tournament.id, "All slots filled (${updatedParticipants.size}/${tournament.totalSlots}). 45s countdown active.")
        }

        // Automatic Match Creation for subsequent players
        if (shouldAutoCreateNext) {
            val nextTourney = autoCreateNextMatch(tournament.mode)
            logAdminAction("AUTO_MATCH_CREATED", nextTourney.id, "Auto-created subsequent ${tournament.mode.tagEn} match (${nextTourney.id}) as $tournamentId is full.")
        }

        return Pair(true, "Successfully joined! Entry ID: $uniqueEntryId (Bound to FF UID: ${user.freeFireUid})")
    }

    // ==========================================
    // AUTOMATIC MATCH CREATION HELPER
    // ==========================================

    private fun autoCreateNextMatch(mode: GameMode): Tournament {
        val now = System.currentTimeMillis()
        val sdf = SimpleDateFormat("hh:mm a", Locale.getDefault())
        return when (mode) {
            GameMode.LONE_WOLF -> {
                val nextNumber = 101 + _tournaments.value.count { it.mode == GameMode.LONE_WOLF }
                val nextId = "T-LW-$nextNumber"
                val newTourney = Tournament(
                    id = nextId,
                    titleEn = "Lone Wolf Quick Cup #$nextNumber",
                    titleBn = "লোন উলফ কুইক কাপ #$nextNumber",
                    mode = GameMode.LONE_WOLF,
                    entryFee = 25,
                    totalPrizePool = 40,
                    totalSlots = 2,
                    mapName = "Iron Cage",
                    startTimeFormatted = sdf.format(Date(now + 10 * 60 * 1000)),
                    startTimeMillis = now + 10 * 60 * 1000,
                    status = TournamentStatus.UPCOMING,
                    roomId = "${(1000000..9999999).random()}",
                    roomPassword = "${(1000..9999).random()}",
                    adminCommission = 10
                )
                _tournaments.value = _tournaments.value + newTourney
                newTourney
            }
            GameMode.CLASH_SQUAD -> {
                val nextNumber = 201 + _tournaments.value.count { it.mode == GameMode.CLASH_SQUAD }
                val nextId = "T-CS-$nextNumber"
                val newTourney = Tournament(
                    id = nextId,
                    titleEn = "Clash Squad Championship #$nextNumber",
                    titleBn = "ক্ল্যাশ স্কোয়াড চ্যাম্পিয়নশিপ #$nextNumber",
                    mode = GameMode.CLASH_SQUAD,
                    entryFee = 20,
                    totalPrizePool = 120,
                    totalSlots = 8,
                    mapName = "Bermuda Kalahari",
                    startTimeFormatted = sdf.format(Date(now + 20 * 60 * 1000)),
                    startTimeMillis = now + 20 * 60 * 1000,
                    status = TournamentStatus.UPCOMING,
                    roomId = "${(1000000..9999999).random()}",
                    roomPassword = "${(1000..9999).random()}",
                    adminCommission = 40
                )
                _tournaments.value = _tournaments.value + newTourney
                newTourney
            }
            GameMode.BATTLE_ROYALE -> {
                val nextNumber = 301 + _tournaments.value.count { it.mode == GameMode.BATTLE_ROYALE }
                val nextId = "T-BR-$nextNumber"
                val newTourney = Tournament(
                    id = nextId,
                    titleEn = "Mega Battle Royale India #$nextNumber",
                    titleBn = "মেগা ব্যাটেল রয়্যাল ইন্ডিয়া #$nextNumber",
                    mode = GameMode.BATTLE_ROYALE,
                    entryFee = 20,
                    totalPrizePool = 570,
                    totalSlots = 40,
                    mapName = "Bermuda",
                    startTimeFormatted = "08:00 PM IST",
                    startTimeMillis = now + 60 * 60 * 1000,
                    status = TournamentStatus.UPCOMING,
                    scheduledDailyTime = "08:00 PM IST",
                    roomId = "${(1000000..9999999).random()}",
                    roomPassword = "${(1000..9999).random()}",
                    adminCommission = 230
                )
                _tournaments.value = _tournaments.value + newTourney
                newTourney
            }
        }
    }

    // ==========================================
    // SYNCHRONIZED 45-SECOND COUNTDOWN TICKER
    // ==========================================

    fun tickCountdowns() {
        val now = System.currentTimeMillis()
        var tourneysChanged = false
        val updatedTourneys = _tournaments.value.map { t ->
            if (t.status == TournamentStatus.CONFIRMED && t.countdownStartMillis != null) {
                val elapsed = now - t.countdownStartMillis
                if (elapsed >= 45_000L && !t.matchStartedNotified) {
                    tourneysChanged = true
                    addNotification(
                        titleEn = "Match Started!",
                        titleBn = "ম্যাচ শুরু হয়েছে!",
                        messageEn = "Match Started! ${t.titleEn} is now LIVE! Your Room ID & Password are now unlocked inside Match Details.",
                        messageBn = "ম্যাচ শুরু হয়েছে! ${t.titleBn} এখন লাইভ! টুর্নামেন্ট ডিটেইলসে গিয়ে আপনার আনলকড রুম আইডি ও পাসওয়ার্ড দেখুন।",
                        type = "MATCH"
                    )
                    t.copy(status = TournamentStatus.LIVE, matchStartedNotified = true)
                } else t
            } else t
        }
        if (tourneysChanged) {
            _tournaments.value = updatedTourneys
        }
    }

    // ==========================================
    // LONE WOLF TIMEOUT & PLAYER REMOVAL
    // ==========================================

    fun cancelLoneWolfWaitingPlayer(tournamentId: String, refundFee: Boolean = true): Pair<Boolean, String> {
        val tourney = _tournaments.value.find { it.id == tournamentId }
            ?: return Pair(false, "Tournament not found")

        if (tourney.mode != GameMode.LONE_WOLF) {
            return Pair(false, "Only applicable to Lone Wolf matchmaking")
        }

        val waitingParticipant = tourney.participants.firstOrNull()
            ?: return Pair(false, "No waiting player found in this match")

        if (refundFee) {
            if (_currentUser.value?.id == waitingParticipant.userId) {
                val wallet = _currentWallet.value
                _currentWallet.value = wallet.copy(depositBalance = wallet.depositBalance + tourney.entryFee)
            }
            val tx = Transaction(
                id = "TX-CANCEL-" + UUID.randomUUID().toString().take(6).uppercase(),
                userId = waitingParticipant.userId,
                type = TransactionType.REFUND,
                amount = tourney.entryFee,
                status = TransactionStatus.SUCCESS,
                timestamp = System.currentTimeMillis(),
                referenceId = tourney.id,
                titleEn = "Entry Fee Refunded",
                titleBn = "এন্ট্রি ফি রিফান্ড সম্পন্ন",
                subtitleEn = "${tourney.titleEn} • Opponent did not join in 45s • ₹${tourney.entryFee} refunded",
                subtitleBn = "${tourney.titleBn} • ৪৫ সেকেন্ডে প্রতিপক্ষ না পাওয়ায় ₹${tourney.entryFee} ফেরত"
            )
            _transactions.value = listOf(tx) + _transactions.value
            addNotification(
                titleEn = "Entry Fee Refunded",
                titleBn = "এন্ট্রি ফি ফেরত দেওয়া হয়েছে",
                messageEn = "Second player did not join within 45 seconds. ₹${tourney.entryFee} returned to your wallet.",
                messageBn = "৪৫ সেকেন্ডে দ্বিতীয় খেলোয়াড় যোগ দেয়নি। ₹${tourney.entryFee} আপনার ওয়ালেটে ফেরত দেওয়া হয়েছে।"
            )
        }

        // Reset match to UPCOMING with empty slots so new players can join
        _tournaments.value = _tournaments.value.map { t ->
            if (t.id == tournamentId) {
                t.copy(
                    participants = emptyList(),
                    status = TournamentStatus.UPCOMING,
                    countdownStartMillis = null,
                    waitingPlayerJoinedAt = null
                )
            } else t
        }

        logAdminAction("MATCHMAKING_CANCELLED", tournamentId, "Waiting player ${waitingParticipant.name} removed (Refunded: $refundFee). Match opened for new players.")
        return Pair(true, "Waiting player removed from Lone Wolf. Match reset for new players.")
    }

    // ==========================================
    // BATTLE ROYALE DAILY SCHEDULE MANAGEMENT
    // ==========================================

    fun updateBattleRoyaleSchedule(
        tournamentId: String,
        newScheduledTime: String,
        entryFee: Int? = null,
        totalSlots: Int? = null,
        mapName: String? = null
    ): Pair<Boolean, String> {
        val user = _currentUser.value ?: return Pair(false, "Not logged in")
        if (!user.isOwner) {
            return Pair(false, "Unauthorized: Owner access required ($BATTLE_ARENA_OWNER_EMAIL)")
        }

        val tourney = _tournaments.value.find { it.id == tournamentId }
            ?: return Pair(false, "Tournament not found")

        _tournaments.value = _tournaments.value.map { t ->
            if (t.id == tournamentId) {
                t.copy(
                    scheduledDailyTime = newScheduledTime,
                    startTimeFormatted = newScheduledTime,
                    entryFee = entryFee ?: t.entryFee,
                    totalSlots = totalSlots ?: t.totalSlots,
                    mapName = mapName ?: t.mapName
                )
            } else t
        }

        // Notify registered participants
        addNotification(
            titleEn = "Battle Royale Schedule Updated",
            titleBn = "ব্যাটেল রয়্যাল সময়সূচী পরিবর্তিত হয়েছে",
            messageEn = "${tourney.titleEn} schedule changed to $newScheduledTime. Please be ready on time!",
            messageBn = "${tourney.titleBn} এর সময় পরিবর্তিত হয়ে $newScheduledTime হয়েছে। সময়মতো প্রস্তুত থাকুন!",
            type = "MATCH"
        )

        logAdminAction("SCHEDULE_UPDATED", tournamentId, "Admin updated scheduled time to $newScheduledTime (Slots: ${totalSlots ?: tourney.totalSlots}, Map: ${mapName ?: tourney.mapName}).")
        return Pair(true, "Schedule updated to $newScheduledTime. Registered players notified!")
    }

    // ==========================================
    // BR PRIZE DISTRIBUTION CHART CONFIGURATION
    // ==========================================

    fun updateBrPrizeChart(
        tournamentId: String,
        newTiers: List<BrPrizeTier>,
        killPrize: Int = 110
    ): Pair<Boolean, String> {
        val user = _currentUser.value ?: return Pair(false, "Not logged in")
        if (!user.isOwner) {
            return Pair(false, "Unauthorized: Owner access required ($BATTLE_ARENA_OWNER_EMAIL)")
        }
        val tourney = _tournaments.value.find { it.id == tournamentId }
            ?: return Pair(false, "Tournament not found")

        val newPlacementPool = newTiers.sumOf { it.totalTierPrize }
        val newTotalPool = newPlacementPool + killPrize

        _tournaments.value = _tournaments.value.map { t ->
            if (t.id == tournamentId) {
                t.copy(
                    brPrizeChart = newTiers,
                    brKillPrizePool = killPrize,
                    totalPrizePool = newTotalPool
                )
            } else t
        }

        logAdminAction(
            "BR_PRIZE_CHART_UPDATED",
            tournamentId,
            "Owner updated prize distribution: ${newTiers.size} tiers, Placement ₹$newPlacementPool + Kills ₹$killPrize = Total ₹$newTotalPool"
        )
        return Pair(true, "Prize distribution chart updated! Total Prize Pool: ₹$newTotalPool across ${newTiers.sumOf { it.totalWinningPositions }} winning positions.")
    }

    // ==========================================
    // MATCH RESULTS & PRIZE PAYMENT APPROVAL
    // ==========================================

    fun verifyMatchResult(
        resultId: String,
        verifiedRank: Int? = null,
        verifiedKills: Int? = null,
        isApproved: Boolean = true
    ): Pair<Boolean, String> {
        val user = _currentUser.value ?: return Pair(false, "Not logged in")
        if (!user.isOwner) {
            return Pair(false, "Unauthorized: Owner access required ($BATTLE_ARENA_OWNER_EMAIL)")
        }

        val record = _matchResults.value.find { it.id == resultId }
            ?: return Pair(false, "Match result record not found")

        if (record.paymentStatus == PrizePaymentStatus.PAID) {
            return Pair(false, "Cannot modify already paid result record.")
        }

        val rank = verifiedRank ?: record.rank
        val kills = verifiedKills ?: record.kills

        val tourney = _tournaments.value.find { it.id == record.tournamentId }
        val participant = tourney?.participants?.find { it.freeFireUid.trim() == record.freeFireUid.trim() }
        val isAuthorized = participant != null && participant.isPaid && participant.verificationStatus != PlayerVerificationStatus.UNAUTHORIZED && participant.verificationStatus != PlayerVerificationStatus.KICKED
        val isCurrentUserAccount = record.userId == "BA-70912" && (participant == null || (participant.isPaid && participant.verificationStatus != PlayerVerificationStatus.UNAUTHORIZED && participant.verificationStatus != PlayerVerificationStatus.KICKED))

        if (isApproved && !isAuthorized && !isCurrentUserAccount) {
            return Pair(false, "Security violation: Player UID ${record.freeFireUid} is not an authorized, paid participant for match ${record.tournamentId}. Unregistered friends or kicked players cannot receive verified official standing.")
        }

        val placementPrize = tourney?.getPrizeForRank(rank) ?: record.placementPrize
        val killPrize = record.killPrize
        val eligiblePrize = placementPrize + killPrize

        _matchResults.value = _matchResults.value.map { r ->
            if (r.id == resultId) {
                r.copy(
                    rank = rank,
                    kills = kills,
                    placementPrize = placementPrize,
                    killPrize = killPrize,
                    eligiblePrize = eligiblePrize,
                    isVerified = true,
                    paymentStatus = if (isApproved) PrizePaymentStatus.APPROVED else PrizePaymentStatus.REJECTED,
                    verifiedBy = user.email
                )
            } else r
        }

        logAdminAction(
            if (isApproved) "RESULT_VERIFIED" else "RESULT_REJECTED",
            resultId,
            "Result for ${record.playerName} (Rank #$rank, Kills: $kills, Prize: ₹$eligiblePrize) verified by ${user.email}."
        )
        return Pair(true, if (isApproved) "Result verified and approved! Eligible prize: ₹$eligiblePrize." else "Result rejected.")
    }

    fun approveAndProcessPrizePayment(resultId: String): Pair<Boolean, String> {
        val user = _currentUser.value ?: return Pair(false, "Not logged in")
        if (!user.isOwner) {
            return Pair(false, "Unauthorized: Owner access required ($BATTLE_ARENA_OWNER_EMAIL)")
        }

        val record = _matchResults.value.find { it.id == resultId }
            ?: return Pair(false, "Match result not found")

        val tourney = _tournaments.value.find { it.id == record.tournamentId }
        val participant = tourney?.participants?.find { it.freeFireUid.trim() == record.freeFireUid.trim() }
        val isAuthorized = participant != null && participant.isPaid && participant.verificationStatus != PlayerVerificationStatus.UNAUTHORIZED && participant.verificationStatus != PlayerVerificationStatus.KICKED
        val isCurrentUserAccount = record.userId == "BA-70912" && (participant == null || (participant.isPaid && participant.verificationStatus != PlayerVerificationStatus.UNAUTHORIZED && participant.verificationStatus != PlayerVerificationStatus.KICKED))

        if (!isAuthorized && !isCurrentUserAccount) {
            return Pair(false, "Security violation: Player ${record.playerName} (FF UID: ${record.freeFireUid}) is not an authorized paid participant for match ${record.tournamentId}. Prize payment is strictly blocked.")
        }

        if (record.paymentStatus == PrizePaymentStatus.PAID || record.payoutUtr != null) {
            return Pair(false, "Duplicate payout blocked: Prize has already been paid for this record (UTR: ${record.payoutUtr}).")
        }

        if (record.paymentStatus == PrizePaymentStatus.REJECTED) {
            return Pair(false, "Cannot process payout for a rejected match result.")
        }

        if (record.eligiblePrize <= 0) {
            return Pair(false, "Eligible prize is ₹0. No payout required.")
        }

        val payoutUtr = "UTR-PRIZE-" + UUID.randomUUID().toString().take(10).uppercase()
        val now = System.currentTimeMillis()

        // Step 1: Credit player winning balance if currently active user
        if (_currentUser.value?.id == record.userId) {
            val wallet = _currentWallet.value
            _currentWallet.value = wallet.copy(winningBalance = wallet.winningBalance + record.eligiblePrize)
        }

        // Step 2: Record player Transaction
        val tx = Transaction(
            id = "WIN-" + UUID.randomUUID().toString().take(6).uppercase(),
            userId = record.userId,
            type = TransactionType.PRIZE_MONEY,
            amount = record.eligiblePrize,
            status = TransactionStatus.SUCCESS,
            timestamp = now,
            referenceId = payoutUtr,
            titleEn = "Tournament Prize: ${record.tournamentTitle}",
            titleBn = "টুর্নামেন্ট পুরস্কার: ${record.tournamentTitle}",
            subtitleEn = "Rank #${record.rank} • ₹${record.eligiblePrize} credited (UTR: $payoutUtr)",
            subtitleBn = "র‍্যাঙ্ক #${record.rank} • ₹${record.eligiblePrize} উইনিংসে যুক্ত (ইউটিআর: $payoutUtr)"
        )
        _transactions.value = listOf(tx) + _transactions.value

        // Step 3: Update Admin Wallet & Ledger
        val aw = _adminWallet.value
        _adminWallet.value = aw.copy(
            totalPrizePaid = aw.totalPrizePaid + record.eligiblePrize
        )
        val ledgerEntry = AdminLedgerEntry(
            id = "LEDGER-PRIZE-${record.id}-$now",
            type = AdminLedgerEntryType.MATCH_COMMISSION,
            amount = record.eligiblePrize,
            descriptionEn = "Prize Payout: ${record.playerName} (Rank #${record.rank}, ₹${record.eligiblePrize}, UTR: $payoutUtr)",
            descriptionBn = "পুরস্কার প্রদান: ${record.playerName} (র‍্যাঙ্ক #${record.rank}, ₹${record.eligiblePrize}, ইউটিআর: $payoutUtr)",
            referenceId = payoutUtr
        )
        _adminLedger.value = listOf(ledgerEntry) + _adminLedger.value

        // Step 4: Update Result Record
        _matchResults.value = _matchResults.value.map { r ->
            if (r.id == resultId) {
                r.copy(
                    isVerified = true,
                    paymentStatus = PrizePaymentStatus.PAID,
                    payoutUtr = payoutUtr,
                    payoutTimestamp = now,
                    verifiedBy = user.email
                )
            } else r
        }

        // Step 5: Notify player
        addNotification(
            titleEn = "Prize Money Disbursed: ₹${record.eligiblePrize}",
            titleBn = "পুরস্কারের টাকা প্রদান সম্পন্ন: ₹${record.eligiblePrize}",
            messageEn = "Congratulations! ₹${record.eligiblePrize} for Rank #${record.rank} in ${record.tournamentTitle} has been deposited to your Winning Wallet. UTR: $payoutUtr.",
            messageBn = "অভিনন্দন! ${record.tournamentTitle}-এ র‍্যাঙ্ক #${record.rank}-এর জন্য ₹${record.eligiblePrize} আপনার উইনিং ওয়ালেটে জমা হয়েছে। ইউটিআর: $payoutUtr।",
            type = "PAYMENT"
        )

        logAdminAction(
            "PRIZE_PAYOUT_APPROVED",
            resultId,
            "Owner approved ₹${record.eligiblePrize} prize payment to ${record.playerName} (UTR: $payoutUtr)."
        )

        return Pair(true, "Prize payment of ₹${record.eligiblePrize} approved and transferred! UTR: $payoutUtr.")
    }

    // ==========================================
    // AUTHORIZED PLAYERS & ANTI-FREE ENTRY AUDIT
    // ==========================================

    fun getAuthorizedPlayers(tournamentId: String): List<PlayerParticipant> {
        return _tournaments.value.find { it.id == tournamentId }?.participants ?: emptyList()
    }

    fun verifyRoomPlayer(
        tournamentId: String,
        freeFireUid: String,
        newStatus: PlayerVerificationStatus,
        notes: String? = null
    ): Pair<Boolean, String> {
        val user = _currentUser.value ?: return Pair(false, "Not logged in")
        if (!user.isOwner) {
            return Pair(false, "Unauthorized: Owner access required ($BATTLE_ARENA_OWNER_EMAIL)")
        }

        val tourney = _tournaments.value.find { it.id == tournamentId }
            ?: return Pair(false, "Tournament not found")

        val targetParticipant = tourney.participants.find { it.freeFireUid.trim() == freeFireUid.trim() }
            ?: return Pair(false, "Player with FF UID $freeFireUid not found in tournament $tournamentId")

        _tournaments.value = _tournaments.value.map { t ->
            if (t.id == tournamentId) {
                t.copy(
                    participants = t.participants.map { p ->
                        if (p.freeFireUid.trim() == freeFireUid.trim()) {
                            p.copy(
                                verificationStatus = newStatus,
                                adminNotes = notes ?: p.adminNotes,
                                checkedInAt = System.currentTimeMillis()
                            )
                        } else p
                    }
                )
            } else t
        }

        logAdminAction(
            "PLAYER_VERIFICATION_UPDATED",
            tournamentId,
            "Owner updated player ${targetParticipant.freeFireName} ($freeFireUid) to $newStatus (Notes: ${notes ?: "None"})"
        )

        return Pair(true, "Player ${targetParticipant.freeFireName} ($freeFireUid) marked as $newStatus")
    }

    fun removeUnauthorizedPlayer(
        tournamentId: String,
        freeFireUid: String,
        reason: String,
        shouldRefund: Boolean = false
    ): Pair<Boolean, String> {
        val user = _currentUser.value ?: return Pair(false, "Not logged in")
        if (!user.isOwner) {
            return Pair(false, "Unauthorized: Owner access required ($BATTLE_ARENA_OWNER_EMAIL)")
        }

        val tourney = _tournaments.value.find { it.id == tournamentId }
            ?: return Pair(false, "Tournament not found")

        val targetParticipant = tourney.participants.find { it.freeFireUid.trim() == freeFireUid.trim() }
            ?: return Pair(false, "Player with FF UID $freeFireUid not found in tournament $tournamentId")

        // If refund is requested and player paid entry fee
        if (shouldRefund && targetParticipant.isPaid && targetParticipant.entryFeePaid > 0) {
            if (_currentUser.value?.id == targetParticipant.userId) {
                val wallet = _currentWallet.value
                _currentWallet.value = wallet.copy(
                    depositBalance = wallet.depositBalance + targetParticipant.entryFeePaid
                )
            }
            val refundTx = Transaction(
                id = "REF-" + UUID.randomUUID().toString().take(6).uppercase(),
                userId = targetParticipant.userId,
                type = TransactionType.REFUND,
                amount = targetParticipant.entryFeePaid,
                status = TransactionStatus.SUCCESS,
                timestamp = System.currentTimeMillis(),
                referenceId = tournamentId,
                titleEn = "Entry Fee Refund: ${tourney.titleEn}",
                titleBn = "এন্ট্রি ফি রিফান্ড: ${tourney.titleBn}",
                subtitleEn = "Admin removed player from room: $reason",
                subtitleBn = "অ্যাডমিন রুম থেকে রিমুভ করেছেন: $reason"
            )
            _transactions.value = listOf(refundTx) + _transactions.value
        }

        _tournaments.value = _tournaments.value.map { t ->
            if (t.id == tournamentId) {
                t.copy(
                    participants = t.participants.map { p ->
                        if (p.freeFireUid.trim() == freeFireUid.trim()) {
                            p.copy(
                                verificationStatus = PlayerVerificationStatus.KICKED,
                                adminNotes = "Kicked: $reason"
                            )
                        } else p
                    }
                )
            } else t
        }

        addNotification(
            titleEn = "Removed from Match (#$tournamentId)",
            titleBn = "ম্যাচ থেকে রিমুভ করা হয়েছে (#$tournamentId)",
            messageEn = "You were removed from ${tourney.titleEn}. Reason: $reason. Room access revoked.${if (shouldRefund) " Entry fee refunded." else ""}",
            messageBn = "আপনাকে ${tourney.titleBn} থেকে রিমুভ করা হয়েছে। কারণ: $reason। রুম অ্যাক্সেস বাতিল।",
            type = "SECURITY"
        )

        logAdminAction(
            "PLAYER_KICKED_FROM_ROOM",
            tournamentId,
            "Owner kicked FF UID $freeFireUid (${targetParticipant.freeFireName}) from room. Reason: $reason. Refunded: $shouldRefund"
        )

        return Pair(true, "Player $freeFireUid successfully kicked from room. Room credentials revoked.")
    }

    fun auditRoomRoster(tournamentId: String, roomPlayerUids: List<String>): RoomRosterAuditReport {
        val tourney = _tournaments.value.find { it.id == tournamentId }
        val cleanRoomUids = roomPlayerUids.map { it.trim() }.filter { it.isNotBlank() }.distinct()

        val registeredUids = tourney?.participants
            ?.filter { it.isPaid && it.verificationStatus != PlayerVerificationStatus.KICKED }
            ?.map { it.freeFireUid.trim() } ?: emptyList()

        // Unauthorized: players found in the in-game room whose UIDs are NOT in registered authorized list
        val unauthorizedUids = cleanRoomUids.filter { uid -> !registeredUids.contains(uid) }

        // Authorized in room
        val authorizedCount = cleanRoomUids.count { uid -> registeredUids.contains(uid) }

        // Missing registered players who haven't entered the room yet
        val missingAuthorizedUids = registeredUids.filter { uid -> !cleanRoomUids.contains(uid) }

        val report = RoomRosterAuditReport(
            tournamentId = tournamentId,
            totalAudited = cleanRoomUids.size,
            authorizedCount = authorizedCount,
            unauthorizedUids = unauthorizedUids,
            missingAuthorizedUids = missingAuthorizedUids,
            timestamp = System.currentTimeMillis()
        )

        if (unauthorizedUids.isNotEmpty()) {
            logAdminAction(
                "FREE_ENTRY_DETECTED",
                tournamentId,
                "🚨 Free Entry Detected! ${unauthorizedUids.size} unauthorized UIDs in room: ${unauthorizedUids.joinToString(", ")}. Action: Must be kicked before start."
            )
        }

        return report
    }

    // ==========================================
    // UNSUCCESSFUL MATCH & ENTRY FEE REFUNDS
    // ==========================================

    fun markTournamentUnsuccessful(tournamentId: String, reason: String = "Technical or server issue"): Pair<Boolean, String> {
        val user = _currentUser.value ?: return Pair(false, "Not logged in")
        if (!user.isOwner) {
            return Pair(false, "Unauthorized: Owner access required ($BATTLE_ARENA_OWNER_EMAIL)")
        }

        val tourney = _tournaments.value.find { it.id == tournamentId }
            ?: return Pair(false, "Tournament not found")

        if (tourney.status == TournamentStatus.COMPLETED) {
            return Pair(false, "Completed matches cannot be marked unsuccessful")
        }

        _tournaments.value = _tournaments.value.map { t ->
            if (t.id == tournamentId) {
                t.copy(status = TournamentStatus.UNSUCCESSFUL)
            } else t
        }

        // Generate refund items for all registered participants who haven't been refunded yet
        val newRefundItems = tourney.participants
            .filter { p -> !tourney.refundedPlayerIds.contains(p.userId) }
            .map { p ->
                MatchRefundItem(
                    id = "REFUND-${tourney.id}-${p.userId}",
                    tournamentId = tourney.id,
                    tournamentTitle = tourney.titleEn,
                    userId = p.userId,
                    userName = p.name,
                    freeFireUid = p.freeFireUid,
                    entryFee = tourney.entryFee,
                    status = RefundStatus.PENDING,
                    reason = reason,
                    approvedBy = ""
                )
            }

        val existingIds = _refundRecords.value.map { it.id }.toSet()
        val itemsToAdd = newRefundItems.filter { it.id !in existingIds }
        _refundRecords.value = itemsToAdd + _refundRecords.value

        addNotification(
            titleEn = "Match Marked Unsuccessful: ${tourney.titleEn}",
            titleBn = "ম্যাচ সফল হয়নি চিহ্নিত: ${tourney.titleBn}",
            messageEn = "Reason: $reason. Entry fees are queued for Admin wallet refund.",
            messageBn = "কারণ: $reason। এন্ট্রি ফি ওয়ালেটে রিফান্ডের জন্য প্রস্তুত।"
        )

        logAdminAction("MATCH_MARKED_UNSUCCESSFUL", tournamentId, "Marked unsuccessful ($reason). ${itemsToAdd.size} refund requests queued.")
        return Pair(true, "Match marked as Unsuccessful. ${itemsToAdd.size} player refunds queued for Admin approval.")
    }

    fun approveAndProcessMatchRefund(tournamentId: String, refundItemId: String? = null): Pair<Boolean, String> {
        val user = _currentUser.value ?: return Pair(false, "Not logged in")
        if (!user.isOwner) {
            return Pair(false, "Unauthorized: Owner access required ($BATTLE_ARENA_OWNER_EMAIL)")
        }

        val tourney = _tournaments.value.find { it.id == tournamentId }
            ?: return Pair(false, "Tournament not found")

        val targetItems = if (refundItemId != null) {
            _refundRecords.value.filter { it.id == refundItemId && it.status == RefundStatus.PENDING }
        } else {
            _refundRecords.value.filter { it.tournamentId == tournamentId && it.status == RefundStatus.PENDING }
        }

        if (targetItems.isEmpty()) {
            val isAlreadyRefunded = _refundRecords.value.any {
                (refundItemId != null && it.id == refundItemId && it.status == RefundStatus.REFUNDED) ||
                (refundItemId == null && it.tournamentId == tournamentId && it.status == RefundStatus.REFUNDED)
            }
            if (isAlreadyRefunded) {
                return Pair(false, "Already refunded: this entry fee has already been processed.")
            }
            return Pair(false, "No pending refunds found for this match")
        }

        var totalRefundedAmount = 0
        val refundedUserIds = mutableListOf<String>()

        targetItems.forEach { item ->
            // Prevent duplicate refunds
            if (!tourney.refundedPlayerIds.contains(item.userId)) {
                refundedUserIds.add(item.userId)
                totalRefundedAmount += item.entryFee

                // Credit player's wallet if active user
                if (_currentUser.value?.id == item.userId) {
                    val wallet = _currentWallet.value
                    _currentWallet.value = wallet.copy(depositBalance = wallet.depositBalance + item.entryFee)
                }

                // Add Transaction entry with type REFUND
                val tx = Transaction(
                    id = "TX-REFUND-" + UUID.randomUUID().toString().take(6).uppercase(),
                    userId = item.userId,
                    type = TransactionType.REFUND,
                    amount = item.entryFee,
                    status = TransactionStatus.SUCCESS,
                    timestamp = System.currentTimeMillis(),
                    referenceId = tourney.id,
                    titleEn = "Entry Fee Refunded",
                    titleBn = "এন্ট্রি ফি রিফান্ড সম্পন্ন",
                    subtitleEn = "${tourney.titleEn} • ₹${item.entryFee} refunded to Deposit Wallet",
                    subtitleBn = "${tourney.titleBn} • ₹${item.entryFee} ওয়ালেটে ফেরত দেওয়া হয়েছে"
                )
                _transactions.value = listOf(tx) + _transactions.value

                addNotification(
                    titleEn = "Entry Fee Refunded: ₹${item.entryFee}",
                    titleBn = "এন্ট্রি ফি ফেরত দেওয়া হয়েছে: ₹${item.entryFee}",
                    messageEn = "Your entry fee for ${tourney.titleEn} has been returned to your wallet. Reason: ${item.reason}",
                    messageBn = "${tourney.titleBn} এর জন্য আপনার এন্ট্রি ফি ওয়ালেটে জমা হয়েছে। কারণ: ${item.reason}",
                    type = "PAYMENT"
                )
            }
        }

        // Update refund records status to REFUNDED
        _refundRecords.value = _refundRecords.value.map { item ->
            if (targetItems.any { it.id == item.id }) {
                item.copy(
                    status = RefundStatus.REFUNDED,
                    processedAt = System.currentTimeMillis(),
                    approvedBy = user.email
                )
            } else item
        }

        // Mark tournament as refunded to prevent duplicate processing
        val allRefundedIds = (tourney.refundedPlayerIds + refundedUserIds).distinct()
        val allDone = allRefundedIds.size >= tourney.participants.size
        _tournaments.value = _tournaments.value.map { t ->
            if (t.id == tournamentId) {
                t.copy(
                    isRefundProcessed = allDone,
                    refundedPlayerIds = allRefundedIds
                )
            } else t
        }

        if (totalRefundedAmount > 0) {
            val aw = _adminWallet.value
            _adminWallet.value = aw.copy(
                totalRefundsPaid = aw.totalRefundsPaid + totalRefundedAmount
            )
            val refundLedger = AdminLedgerEntry(
                id = "LEDGER-REFUND-${tourney.id}-${System.currentTimeMillis()}",
                type = AdminLedgerEntryType.REFUND_DEDUCTION,
                amount = totalRefundedAmount,
                descriptionEn = "Refund Disbursed: ${tourney.titleEn} (Total: ₹$totalRefundedAmount)",
                descriptionBn = "রিফান্ড সম্পন্ন: ${tourney.titleBn} (মোট: ₹$totalRefundedAmount)",
                referenceId = tourney.id
            )
            _adminLedger.value = listOf(refundLedger) + _adminLedger.value
        }

        logAdminAction("REFUND_APPROVED", tournamentId, "Approved refund of ₹$totalRefundedAmount to ${refundedUserIds.size} players.")
        return Pair(true, "Successfully refunded ₹$totalRefundedAmount to ${refundedUserIds.size} player wallets. Transaction history updated.")
    }

    // ==========================================
    // REFERRAL SYSTEM
    // ==========================================

    fun applyReferralCode(code: String): Pair<Boolean, String> {
        val user = _currentUser.value ?: return Pair(false, "Not logged in")
        if (user.referredBy != null) {
            return Pair(false, "Referral bonus already claimed / রেফারেল বোনাস ইতিমধ্যে গৃহীত হয়েছে")
        }
        if (code.trim().equals(user.referralCode, ignoreCase = true)) {
            return Pair(false, "You cannot use your own referral code (Self-referral prohibited) / নিজের কোড ব্যবহার করা যাবে না")
        }

        // Credit ₹5 bonus to user
        val wallet = _currentWallet.value
        _currentWallet.value = wallet.copy(bonusBalance = wallet.bonusBalance + 5)
        _currentUser.value = user.copy(referredBy = code.trim().uppercase())

        val tx = Transaction(
            id = "REF-" + UUID.randomUUID().toString().take(6).uppercase(),
            userId = user.id,
            type = TransactionType.REFERRAL_BONUS,
            amount = 5,
            status = TransactionStatus.SUCCESS,
            timestamp = System.currentTimeMillis(),
            referenceId = "REF_BONUS_${code.trim()}",
            titleEn = "Referral Bonus (Friend Invite)",
            titleBn = "রেফারেল বোনাস (বন্ধু আমন্ত্রণ)",
            subtitleEn = "₹5 added to Bonus Cash (Referrer also receives ₹5)",
            subtitleBn = "বোনাস ক্যাশে ₹৫ যোগ হয়েছে (আমন্ত্রণকারীও ₹৫ পাবেন)"
        )
        _transactions.value = listOf(tx) + _transactions.value

        return Pair(true, "Referral bonus ₹5 credited to Bonus Cash!")
    }

    // ==========================================
    // FAIR PLAY & CHEAT BAN MANAGEMENT (OWNER ONLY)
    // ==========================================

    fun banPlayer(userId: String, reason: String): Pair<Boolean, String> {
        if (_currentUser.value?.id == userId) {
            _currentUser.value = _currentUser.value?.copy(isBanned = true, banReason = reason)
        }
        val report = IncidentReport(
            id = "REP-${System.currentTimeMillis()}",
            reportedUserId = userId,
            reportedUserName = "Player $userId",
            reportedUserUid = "UID-$userId",
            tournamentId = "GENERAL",
            reason = reason,
            status = "BANNED"
        )
        _incidentReports.value = listOf(report) + _incidentReports.value
        return Pair(true, "Player $userId banned: $reason")
    }

    fun unbanPlayer(userId: String): Pair<Boolean, String> {
        if (_currentUser.value?.id == userId) {
            _currentUser.value = _currentUser.value?.copy(isBanned = false, banReason = null)
        }
        _incidentReports.value = _incidentReports.value.map {
            if (it.reportedUserId == userId) it.copy(status = "RESOLVED") else it
        }
        return Pair(true, "Player $userId unbanned.")
    }

    // ==========================================
    // TOURNAMENT ADMIN CREATION & VERIFICATION
    // ==========================================

    fun createTournament(
        titleEn: String,
        titleBn: String,
        mode: GameMode,
        entryFee: Int = mode.defaultEntryFee,
        startTimeFormatted: String,
        mapName: String = "Bermuda"
    ): Tournament {
        val id = "T-${mode.code}-${(100 + _tournaments.value.size + 1)}"
        val prizePool = when (mode) {
            GameMode.LONE_WOLF -> 40
            GameMode.CLASH_SQUAD -> 120
            GameMode.BATTLE_ROYALE -> 570
        }
        val t = Tournament(
            id = id,
            titleEn = titleEn,
            titleBn = titleBn,
            mode = mode,
            entryFee = entryFee,
            totalPrizePool = prizePool,
            totalSlots = mode.maxPlayers,
            mapName = mapName,
            startTimeFormatted = startTimeFormatted,
            startTimeMillis = System.currentTimeMillis() + 3600000L,
            status = TournamentStatus.UPCOMING,
            roomId = "89${(1000..9999).random()}",
            roomPassword = "${(1000..9999).random()}",
            participants = emptyList()
        )
        _tournaments.value = listOf(t) + _tournaments.value
        return t
    }

    fun updateRoomCredentials(tournamentId: String, roomId: String, roomPass: String) {
        _tournaments.value = _tournaments.value.map { t ->
            if (t.id == tournamentId) {
                t.copy(roomId = roomId, roomPassword = roomPass)
            } else t
        }
    }

    fun updateTournamentDirectly(tournament: Tournament) {
        _tournaments.value = _tournaments.value.map {
            if (it.id == tournament.id) tournament else it
        }
    }

    fun verifyAndDistributeLoneWolf(tournamentId: String, winnerUserId: String) {
        val tournament = _tournaments.value.find { it.id == tournamentId } ?: return
        val winner = tournament.participants.find { it.userId == winnerUserId } 
            ?: tournament.participants.firstOrNull() ?: return

        val prizeAmount = 40
        val commission = 10

        val currentUser = _currentUser.value
        if (currentUser?.id == winner.userId) {
            val wallet = _currentWallet.value
            _currentWallet.value = wallet.copy(winningBalance = wallet.winningBalance + prizeAmount)

            val tx = Transaction(
                id = "WIN-" + UUID.randomUUID().toString().take(6).uppercase(),
                userId = currentUser.id,
                type = TransactionType.PRIZE_MONEY,
                amount = prizeAmount,
                status = TransactionStatus.SUCCESS,
                timestamp = System.currentTimeMillis(),
                referenceId = tournament.id,
                titleEn = "1st Place Winner: ${tournament.titleEn}",
                titleBn = "প্রথম স্থান বিজয়ী: ${tournament.titleBn}",
                subtitleEn = "₹$prizeAmount added to Winnings Cash",
                subtitleBn = "উইনিং ক্যাশে ₹$prizeAmount যোগ হয়েছে"
            )
            _transactions.value = listOf(tx) + _transactions.value
        }

        val commRecord = PlatformCommissionRecord(
            id = "COMM-${System.currentTimeMillis()}",
            tournamentId = tournament.id,
            tournamentTitle = tournament.titleEn,
            mode = GameMode.LONE_WOLF,
            totalEntryCollected = 50,
            totalPrizeDistributed = prizeAmount,
            commissionEarned = commission
        )
        _commissions.value = listOf(commRecord) + _commissions.value

        val awLW = _adminWallet.value
        _adminWallet.value = awLW.copy(
            availableBalance = awLW.availableBalance + commission,
            totalMatchEarnings = awLW.totalMatchEarnings + commission,
            totalPrizePaid = awLW.totalPrizePaid + prizeAmount
        )
        val ledgerLW = AdminLedgerEntry(
            id = "LEDGER-COMM-${tournament.id}-${System.currentTimeMillis()}",
            type = AdminLedgerEntryType.MATCH_COMMISSION,
            amount = commission,
            descriptionEn = "Host Commission: ${tournament.titleEn} (Entry: ₹50, Prize: ₹$prizeAmount)",
            descriptionBn = "হোস্ট কমিশন: ${tournament.titleBn} (কালেকশন ₹৫০, প্রাইজ: ₹$prizeAmount)",
            referenceId = tournament.id
        )
        _adminLedger.value = listOf(ledgerLW) + _adminLedger.value

        val updatedParticipants = tournament.participants.map { p ->
            if (p.userId == winner.userId) {
                p.copy(isWinner = true, prizeEarned = prizeAmount, placement = 1)
            } else {
                p.copy(isWinner = false, prizeEarned = 0, placement = 2)
            }
        }

        _tournaments.value = _tournaments.value.map { t ->
            if (t.id == tournamentId) {
                t.copy(
                    status = TournamentStatus.COMPLETED,
                    participants = updatedParticipants,
                    winnerSummaryEn = "Winner: ${winner.freeFireName} (Prize: ₹$prizeAmount • Commission: ₹$commission)",
                    winnerSummaryBn = "বিজয়ী: ${winner.freeFireName} (পুরস্কার: ₹$prizeAmount • কমিশন: ₹$commission)",
                    adminCommission = commission
                )
            } else t
        }
    }

    fun verifyAndDistributeClashSquad(tournamentId: String, winningTeam: String) {
        val tournament = _tournaments.value.find { it.id == tournamentId } ?: return
        val winningPlayers = tournament.participants.filter { it.team == winningTeam }
        val losingPlayers = tournament.participants.filter { it.team != winningTeam }

        val prizeSteps = listOf(35, 30, 30, 25)
        val commission = 40
        val currentUserId = _currentUser.value?.id

        val updatedWinners = winningPlayers.mapIndexed { idx, p ->
            val prize = prizeSteps.getOrElse(idx) { 25 }
            if (p.userId == currentUserId) {
                val wallet = _currentWallet.value
                _currentWallet.value = wallet.copy(winningBalance = wallet.winningBalance + prize)
                val tx = Transaction(
                    id = "WIN-" + UUID.randomUUID().toString().take(6).uppercase(),
                    userId = p.userId,
                    type = TransactionType.PRIZE_MONEY,
                    amount = prize,
                    status = TransactionStatus.SUCCESS,
                    timestamp = System.currentTimeMillis(),
                    referenceId = tournament.id,
                    titleEn = "Clash Squad Champion ($winningTeam Rank ${idx + 1})",
                    titleBn = "ক্ল্যাশ স্কোয়াড চ্যাম্পিয়ন ($winningTeam র‍্যাঙ্ক ${idx + 1})",
                    subtitleEn = "₹$prize added to Winnings Cash",
                    subtitleBn = "উইনিং ক্যাশে ₹$prize যোগ হয়েছে"
                )
                _transactions.value = listOf(tx) + _transactions.value
            }
            p.copy(isWinner = true, placement = idx + 1, prizeEarned = prize)
        }

        val updatedLosers = losingPlayers.mapIndexed { idx, p ->
            p.copy(isWinner = false, placement = 5 + idx, prizeEarned = 0)
        }

        val commRecord = PlatformCommissionRecord(
            id = "COMM-${System.currentTimeMillis()}",
            tournamentId = tournament.id,
            tournamentTitle = tournament.titleEn,
            mode = GameMode.CLASH_SQUAD,
            totalEntryCollected = 160,
            totalPrizeDistributed = 120,
            commissionEarned = commission
        )
        _commissions.value = listOf(commRecord) + _commissions.value

        val awCS = _adminWallet.value
        _adminWallet.value = awCS.copy(
            availableBalance = awCS.availableBalance + commission,
            totalMatchEarnings = awCS.totalMatchEarnings + commission,
            totalPrizePaid = awCS.totalPrizePaid + 120
        )
        val ledgerCS = AdminLedgerEntry(
            id = "LEDGER-COMM-${tournament.id}-${System.currentTimeMillis()}",
            type = AdminLedgerEntryType.MATCH_COMMISSION,
            amount = commission,
            descriptionEn = "Host Commission: ${tournament.titleEn} (Entry: ₹160, Prize: ₹120)",
            descriptionBn = "হোস্ট কমিশন: ${tournament.titleBn} (কালেকশন ₹১৬০, প্রাইজ: ₹১২০)",
            referenceId = tournament.id
        )
        _adminLedger.value = listOf(ledgerCS) + _adminLedger.value

        _tournaments.value = _tournaments.value.map { t ->
            if (t.id == tournamentId) {
                t.copy(
                    status = TournamentStatus.COMPLETED,
                    participants = updatedWinners + updatedLosers,
                    winnerSummaryEn = "Victory: $winningTeam won ₹120 (₹35, ₹30, ₹30, ₹25). Host Commission: ₹$commission",
                    winnerSummaryBn = "বিজয়ী: $winningTeam পেয়েছে ₹১২০ (₹৩৫, ₹৩০, ₹৩০, ₹২৫)। কমিশন: ₹৪০",
                    adminCommission = commission
                )
            } else t
        }
    }

    fun verifyAndDistributeBattleRoyale(tournamentId: String) {
        val tournament = _tournaments.value.find { it.id == tournamentId } ?: return
        val currentUserId = _currentUser.value?.id

        val placementPrizeMap = mapOf(
            1 to 100, 2 to 70, 3 to 50, 4 to 50, 5 to 40,
            6 to 30, 7 to 30, 8 to 30, 9 to 30, 10 to 30
        )
        val killPrizeMap = mapOf(
            1 to 30, 2 to 25, 3 to 20, 4 to 20, 5 to 15
        )

        val participants = tournament.participants.toMutableList()
        val sortedByKills = participants.sortedByDescending { it.kills }

        val killRankMap = mutableMapOf<String, Int>()
        sortedByKills.take(5).forEachIndexed { idx, p ->
            killRankMap[p.userId] = idx + 1
        }

        var totalPrizeDistributed = 0
        val updatedParticipants = participants.mapIndexed { idx, p ->
            val placement = p.placement.takeIf { it > 0 } ?: (idx + 1)
            val placementPrize = placementPrizeMap[placement] ?: 0
            val killRank = killRankMap[p.userId]
            val killPrize = if (killRank != null) killPrizeMap[killRank] ?: 0 else 0
            val totalPlayerPrize = placementPrize + killPrize
            totalPrizeDistributed += totalPlayerPrize

            if (p.userId == currentUserId && totalPlayerPrize > 0) {
                val wallet = _currentWallet.value
                _currentWallet.value = wallet.copy(winningBalance = wallet.winningBalance + totalPlayerPrize)
                val tx = Transaction(
                    id = "WIN-" + UUID.randomUUID().toString().take(6).uppercase(),
                    userId = p.userId,
                    type = TransactionType.PRIZE_MONEY,
                    amount = totalPlayerPrize,
                    status = TransactionStatus.SUCCESS,
                    timestamp = System.currentTimeMillis(),
                    referenceId = tournament.id,
                    titleEn = "BR Prize: Rank #$placement (Placement ₹$placementPrize + Kill ₹$killPrize)",
                    titleBn = "বিআর প্রাইজ: র‍্যাঙ্ক #$placement (প্লেসমেন্ট ₹$placementPrize + কিল ₹$killPrize)",
                    subtitleEn = "₹$totalPlayerPrize added to Winnings Cash",
                    subtitleBn = "উইনিং ক্যাশে ₹$totalPlayerPrize যোগ হয়েছে"
                )
                _transactions.value = listOf(tx) + _transactions.value
            }

            p.copy(
                placement = placement,
                prizeEarned = totalPlayerPrize,
                isWinner = placement <= 3
            )
        }

        val commission = 230
        val commRecord = PlatformCommissionRecord(
            id = "COMM-${System.currentTimeMillis()}",
            tournamentId = tournament.id,
            tournamentTitle = tournament.titleEn,
            mode = GameMode.BATTLE_ROYALE,
            totalEntryCollected = 800,
            totalPrizeDistributed = 570,
            commissionEarned = commission
        )
        _commissions.value = listOf(commRecord) + _commissions.value

        val awBR = _adminWallet.value
        _adminWallet.value = awBR.copy(
            availableBalance = awBR.availableBalance + commission,
            totalMatchEarnings = awBR.totalMatchEarnings + commission,
            totalPrizePaid = awBR.totalPrizePaid + 570
        )
        val ledgerBR = AdminLedgerEntry(
            id = "LEDGER-COMM-${tournament.id}-${System.currentTimeMillis()}",
            type = AdminLedgerEntryType.MATCH_COMMISSION,
            amount = commission,
            descriptionEn = "Host Commission: ${tournament.titleEn} (Entry: ₹800, Prize: ₹570)",
            descriptionBn = "হোস্ট কমিশন: ${tournament.titleBn} (কালেকশন ₹৮০০, প্রাইজ: ₹৫৭০)",
            referenceId = tournament.id
        )
        _adminLedger.value = listOf(ledgerBR) + _adminLedger.value

        val top1 = updatedParticipants.find { it.placement == 1 }?.freeFireName ?: "Champion"
        _tournaments.value = _tournaments.value.map { t ->
            if (t.id == tournamentId) {
                t.copy(
                    status = TournamentStatus.COMPLETED,
                    participants = updatedParticipants,
                    winnerSummaryEn = "Top 1: $top1 • Total Prize: ₹570 (Placement ₹460 + Kills ₹110) • Host Balance: ₹$commission",
                    winnerSummaryBn = "১ম স্থান: $top1 • মোট প্রাইজ: ₹৫৭০ (প্লেসমেন্ট ₹৪৬০ + কিল ₹১১০) • কমিশন: ₹২৩০",
                    adminCommission = commission
                )
            } else t
        }
    }

    fun toggleAdminMode() {
        val user = _currentUser.value ?: return
        _currentUser.value = user.copy(isAdmin = !user.isAdmin)
    }

    fun addMoney(amount: Int, method: String): Boolean {
        val pseudoUtr = "UTR" + System.currentTimeMillis().toString().takeLast(8)
        val (success, _) = submitAddMoneyRequest(amount, method, pseudoUtr, "Direct In-App Deposit")
        return success
    }

    // ==========================================
    // OWNER ADMIN WALLET & UPI WITHDRAWALS
    // ==========================================

    fun saveOwnerVerifiedUpiId(newUpiId: String): Pair<Boolean, String> {
        val user = _currentUser.value ?: return Pair(false, "Not logged in")
        if (!user.isOwner) {
            return Pair(false, "Unauthorized: Only the verified app Owner ($BATTLE_ARENA_OWNER_EMAIL) can configure payout destination.")
        }
        val cleanUpi = newUpiId.trim()
        val upiRegex = Regex("^[a-zA-Z0-9.\\-_]{2,256}@[a-zA-Z]{2,64}$")
        if (!upiRegex.matches(cleanUpi)) {
            return Pair(false, "Invalid UPI ID format. Example: name@okhdfcbank or 9876543210@paytm")
        }
        _adminWallet.value = _adminWallet.value.copy(
            verifiedUpiId = cleanUpi,
            isUpiVerified = true
        )
        logAdminAction("OWNER_UPI_UPDATED", cleanUpi, "Owner verified payout UPI ID set to $cleanUpi")
        return Pair(true, "Owner UPI ID verified and saved: $cleanUpi")
    }

    fun requestAdminUPIWithdrawal(
        amount: Int,
        upiId: String,
        autoProcessSuccess: Boolean = true
    ): Pair<Boolean, String> {
        val user = _currentUser.value ?: return Pair(false, "Not logged in")
        if (!user.isOwner) {
            return Pair(false, "Unauthorized: Only the verified app Owner ($BATTLE_ARENA_OWNER_EMAIL) can authorize Admin Wallet withdrawals.")
        }

        if (amount <= 0) {
            return Pair(false, "Withdrawal amount must be greater than ₹0.")
        }

        val wallet = _adminWallet.value
        if (amount > wallet.availableBalance) {
            return Pair(false, "Insufficient available balance. Available: ₹${wallet.availableBalance}, Requested: ₹$amount.")
        }

        val cleanUpi = upiId.trim()
        val upiRegex = Regex("^[a-zA-Z0-9.\\-_]{2,256}@[a-zA-Z]{2,64}$")
        if (!upiRegex.matches(cleanUpi)) {
            return Pair(false, "Invalid destination UPI ID. Format must be username@bank.")
        }

        // Prevent duplicate concurrent withdrawals within 60s
        val hasActiveWithdrawal = _adminWithdrawals.value.any {
            (it.status == AdminWithdrawalStatus.PENDING || it.status == AdminWithdrawalStatus.PROCESSING) &&
            it.amount == amount &&
            (System.currentTimeMillis() - it.requestedAt) < 60_000L
        }
        if (hasActiveWithdrawal) {
            return Pair(false, "A duplicate withdrawal request of ₹$amount is already being processed. Please wait.")
        }

        val withdrawalId = "ADM-WD-" + UUID.randomUUID().toString().take(8).uppercase()
        val providerRef = "RZPX-PAY-" + UUID.randomUUID().toString().take(10).uppercase()
        val idempotencyKey = "IDEM-$withdrawalId"

        // Step 1: Reserve funds immediately from available balance to prevent concurrent drain
        _adminWallet.value = wallet.copy(
            availableBalance = wallet.availableBalance - amount,
            reservedBalance = wallet.reservedBalance + amount
        )

        val record = AdminWithdrawalRecord(
            id = withdrawalId,
            amount = amount,
            destinationUpiId = cleanUpi,
            status = if (autoProcessSuccess) AdminWithdrawalStatus.PROCESSING else AdminWithdrawalStatus.PENDING,
            providerReference = providerRef,
            payoutUtr = "",
            requestedAt = System.currentTimeMillis(),
            idempotencyKey = idempotencyKey
        )
        _adminWithdrawals.value = listOf(record) + _adminWithdrawals.value

        logAdminAction("OWNER_WITHDRAWAL_INITIATED", withdrawalId, "Amount: ₹$amount to $cleanUpi. Provider Ref: $providerRef")

        // Step 2: Payment Provider Authorized Payout Execution
        if (autoProcessSuccess) {
            val utr = "UPI" + System.currentTimeMillis() + (100..999).random()
            val currentWallet = _adminWallet.value
            _adminWallet.value = currentWallet.copy(
                reservedBalance = maxOf(0, currentWallet.reservedBalance - amount),
                totalWithdrawalsPaid = currentWallet.totalWithdrawalsPaid + amount
            )

            _adminWithdrawals.value = _adminWithdrawals.value.map {
                if (it.id == withdrawalId) {
                    it.copy(
                        status = AdminWithdrawalStatus.SUCCESS,
                        payoutUtr = utr,
                        processedAt = System.currentTimeMillis()
                    )
                } else it
            }

            val ledgerEntry = AdminLedgerEntry(
                id = "LEDGER-WD-$withdrawalId",
                type = AdminLedgerEntryType.UPI_WITHDRAWAL,
                amount = amount,
                descriptionEn = "Owner UPI Payout: ₹$amount to $cleanUpi (UTR: $utr)",
                descriptionBn = "মালিকের ইউপিআই পেআউট: ₹$amount ($cleanUpi)",
                referenceId = withdrawalId
            )
            _adminLedger.value = listOf(ledgerEntry) + _adminLedger.value

            logAdminAction("OWNER_WITHDRAWAL_SUCCESS", withdrawalId, "Payout successful. UTR: $utr")
            return Pair(true, "Withdrawal of ₹$amount to $cleanUpi was successful! Payout UTR: $utr")
        }

        return Pair(true, "Withdrawal request of ₹$amount to $cleanUpi submitted and processing.")
    }

    fun failAdminWithdrawal(withdrawalId: String, reason: String = "Payment provider declined / bank timeout"): Pair<Boolean, String> {
        val user = _currentUser.value ?: return Pair(false, "Not logged in")
        if (!user.isOwner) {
            return Pair(false, "Unauthorized: Owner access required")
        }

        val target = _adminWithdrawals.value.find { it.id == withdrawalId }
            ?: return Pair(false, "Withdrawal record not found")

        if (target.status != AdminWithdrawalStatus.PENDING && target.status != AdminWithdrawalStatus.PROCESSING) {
            return Pair(false, "Only pending or processing withdrawals can be marked as failed")
        }

        // Release reserved funds back to available balance
        val wallet = _adminWallet.value
        _adminWallet.value = wallet.copy(
            availableBalance = wallet.availableBalance + target.amount,
            reservedBalance = maxOf(0, wallet.reservedBalance - target.amount)
        )

        _adminWithdrawals.value = _adminWithdrawals.value.map {
            if (it.id == withdrawalId) {
                it.copy(
                    status = AdminWithdrawalStatus.FAILED,
                    failureReason = reason,
                    processedAt = System.currentTimeMillis()
                )
            } else it
        }

        logAdminAction("OWNER_WITHDRAWAL_FAILED", withdrawalId, "Failed: $reason. ₹${target.amount} restored to available balance.")
        return Pair(true, "Withdrawal marked as failed. ₹${target.amount} restored to available balance.")
    }

    fun reverseAdminWithdrawal(withdrawalId: String, reason: String = "Bank settlement reversal / technical dispute"): Pair<Boolean, String> {
        val user = _currentUser.value ?: return Pair(false, "Not logged in")
        if (!user.isOwner) {
            return Pair(false, "Unauthorized: Owner access required")
        }

        val target = _adminWithdrawals.value.find { it.id == withdrawalId }
            ?: return Pair(false, "Withdrawal record not found")

        if (target.status != AdminWithdrawalStatus.SUCCESS) {
            return Pair(false, "Only successful payouts can be reversed")
        }

        // Restore funds to available balance
        val wallet = _adminWallet.value
        _adminWallet.value = wallet.copy(
            availableBalance = wallet.availableBalance + target.amount,
            totalWithdrawalsPaid = maxOf(0, wallet.totalWithdrawalsPaid - target.amount)
        )

        _adminWithdrawals.value = _adminWithdrawals.value.map {
            if (it.id == withdrawalId) {
                it.copy(
                    status = AdminWithdrawalStatus.REVERSED,
                    failureReason = reason,
                    processedAt = System.currentTimeMillis()
                )
            } else it
        }

        val ledgerEntry = AdminLedgerEntry(
            id = "LEDGER-REV-$withdrawalId",
            type = AdminLedgerEntryType.WITHDRAWAL_REVERSAL,
            amount = target.amount,
            descriptionEn = "Payout Reversal: ₹${target.amount} restored ($reason)",
            descriptionBn = "পেআউট রিভার্সাল: ₹${target.amount} ফেরত ($reason)",
            referenceId = withdrawalId
        )
        _adminLedger.value = listOf(ledgerEntry) + _adminLedger.value

        logAdminAction("OWNER_WITHDRAWAL_REVERSED", withdrawalId, "Reversed: $reason. ₹${target.amount} restored.")
        return Pair(true, "Payout reversed. ₹${target.amount} returned to available balance.")
    }

    // ==========================================
    // SEED INITIAL DATA
    // ==========================================

    private fun seedInitialData() {
        val sdf = SimpleDateFormat("hh:mm a", Locale.getDefault())
        val now = System.currentTimeMillis()

        // 1. Lone Wolf (1v1)
        val lw1 = Tournament(
            id = "T-LW-101",
            titleEn = "Lone Wolf Duel #101",
            titleBn = "লোন উলফ ডুয়েল #১০১",
            mode = GameMode.LONE_WOLF,
            entryFee = 25,
            totalPrizePool = 40,
            totalSlots = 2,
            mapName = "Iron Cage",
            startTimeFormatted = sdf.format(Date(now + 15 * 60 * 1000)),
            startTimeMillis = now + 15 * 60 * 1000,
            status = TournamentStatus.LIVE,
            roomId = "8920194",
            roomPassword = "7788",
            participants = listOf(
                PlayerParticipant("P-101", "Subhajit Roy", "亗SUBHO_FF亗", "2839104829", kills = 0),
                PlayerParticipant("BA-70912", "Manik Hunter", "⚡MANIK_BOSS⚡", "2948109382", kills = 0)
            )
        )

        // 2. Clash Squad (4v4)
        val cs1 = Tournament(
            id = "T-CS-201",
            titleEn = "Clash Squad Championship #201",
            titleBn = "ক্ল্যাশ স্কোয়াড চ্যাম্পিয়নশিপ #২০১",
            mode = GameMode.CLASH_SQUAD,
            entryFee = 20,
            totalPrizePool = 120,
            totalSlots = 8,
            mapName = "Bermuda Kalahari",
            startTimeFormatted = sdf.format(Date(now + 45 * 60 * 1000)),
            startTimeMillis = now + 45 * 60 * 1000,
            status = TournamentStatus.UPCOMING,
            roomId = "9182301",
            roomPassword = "4422",
            participants = listOf(
                PlayerParticipant("P-201", "Rahul Das", "RAHUL_SNIPER", "3829104812", team = "Team A"),
                PlayerParticipant("P-202", "Tanmoy Saha", "TANMOY_OP", "4920194821", team = "Team A"),
                PlayerParticipant("P-203", "Bikram Paul", "BIKRAM_YT", "5920194822", team = "Team A"),
                PlayerParticipant("P-204", "Amitabh Ghosh", "AMIT_RUSHER", "6920194823", team = "Team A"),
                PlayerParticipant("P-205", "Rohan Sen", "ROHAN_HEADSHOT", "7920194824", team = "Team B"),
                PlayerParticipant("P-206", "Dipankar Roy", "DIP_GAMER", "8920194825", team = "Team B"),
                PlayerParticipant("BA-70912", "Manik Hunter", "⚡MANIK_BOSS⚡", "2948109382", team = "Team B")
            )
        )

        // 3. Battle Royale (40 Players) - 32 slots filled, current user (BA-70912) not joined yet
        val brParticipants = listOf(
            PlayerParticipant("P-101", "Subhajit Roy", "SUBHA_FIRE", "2839104829", kills = 4, placement = 2, prizeEarned = 95, isPaid = true, entryFeePaid = 20),
            PlayerParticipant("P-201", "Rahul Das", "RAHUL_SNIPER", "3829104812", kills = 3, placement = 3, prizeEarned = 70, isPaid = true, entryFeePaid = 20),
            PlayerParticipant("P-301", "Kushal Kar", "KUSHAL_OP", "4829104813", kills = 2, placement = 4, prizeEarned = 40, isPaid = true, entryFeePaid = 20),
            PlayerParticipant("P-401", "Debojit Dey", "DEBO_PRO", "5829104814", kills = 1, placement = 5, prizeEarned = 35, isPaid = true, entryFeePaid = 20)
        ) + (5..32).map { i ->
            PlayerParticipant(
                userId = "BR-P-$i",
                name = "FF Player $i",
                freeFireName = "PRO_WARRIOR_$i",
                freeFireUid = "9820194${i + 10}",
                kills = (0..6).random(),
                isPaid = true,
                entryFeePaid = 20
            )
        }
        val br1 = Tournament(
            id = "T-BR-301",
            titleEn = "Mega Battle Royale India #301",
            titleBn = "মেগা ব্যাটেল রয়্যাল ইন্ডিয়া #৩০১",
            mode = GameMode.BATTLE_ROYALE,
            entryFee = 20,
            totalPrizePool = 570,
            totalSlots = 40,
            mapName = "Bermuda",
            startTimeFormatted = sdf.format(Date(now + 90 * 60 * 1000)),
            startTimeMillis = now + 90 * 60 * 1000,
            status = TournamentStatus.UPCOMING,
            roomId = "4490192",
            roomPassword = "9900",
            participants = brParticipants
        )

        // 4. Completed Tournament
        val completedLw = Tournament(
            id = "T-LW-100",
            titleEn = "Lone Wolf Quick Cup #100",
            titleBn = "লোন উলফ কুইক কাপ #১০০",
            mode = GameMode.LONE_WOLF,
            entryFee = 25,
            totalPrizePool = 40,
            totalSlots = 2,
            mapName = "Iron Cage",
            startTimeFormatted = "Yesterday",
            startTimeMillis = now - 86400000L,
            status = TournamentStatus.COMPLETED,
            roomId = "7720192",
            roomPassword = "3311",
            winnerSummaryEn = "Winner: ⚡MANIK_BOSS⚡ won ₹40 (Commission: ₹10)",
            winnerSummaryBn = "বিজয়ী: ⚡MANIK_BOSS⚡ জিতেছে ₹৪০ (কমিশন: ₹১০)",
            adminCommission = 10,
            participants = listOf(
                PlayerParticipant("BA-70912", "Manik Hunter", "⚡MANIK_BOSS⚡", "2948109382", kills = 5, placement = 1, prizeEarned = 40, isWinner = true),
                PlayerParticipant("P-99", "Arun Sen", "ARUN_99", "1829104821", kills = 2, placement = 2, prizeEarned = 0)
            )
        )

        _tournaments.value = listOf(lw1, cs1, br1, completedLw)

        // Seed Add Money Requests with Manual Verification Pending
        _addMoneyRequests.value = listOf(
            AddMoneyRequest(
                id = "DEP-1001",
                userId = "P-101",
                userName = "Subhajit Roy",
                freeFireUid = "2839104829",
                amount = 100,
                paymentMethod = "PhonePe UPI",
                utrNumber = "UTR492019482910",
                screenshotNote = "Screenshot Verified",
                status = PaymentApprovalStatus.APPROVED,
                requestedAt = now - 86400000L
            ),
            AddMoneyRequest(
                id = "DEP-1002",
                userId = "P-201",
                userName = "Rahul Das",
                freeFireUid = "3829104812",
                amount = 50,
                paymentMethod = "Google Pay",
                utrNumber = "UTR918201948201",
                screenshotNote = "Payment Proof Attached",
                status = PaymentApprovalStatus.PENDING,
                requestedAt = now - 3600000L
            )
        )

        // Initial Transactions
        _transactions.value = listOf(
            Transaction(
                id = "TX-8910",
                userId = "BA-70912",
                type = TransactionType.PRIZE_MONEY,
                amount = 40,
                status = TransactionStatus.SUCCESS,
                timestamp = now - 3600000L * 4,
                referenceId = "T-LW-100",
                titleEn = "Tournament Winning: Lone Wolf #100",
                titleBn = "টুর্নামেন্ট জয়: লোন উলফ #১০০",
                subtitleEn = "₹40 credited to Winnings Cash",
                subtitleBn = "উইনিং ক্যাশে ₹৪০ জমা হয়েছে"
            ),
            Transaction(
                id = "TX-8802",
                userId = "BA-70912",
                type = TransactionType.ENTRY_FEE,
                amount = 25,
                status = TransactionStatus.SUCCESS,
                timestamp = now - 3600000L * 6,
                referenceId = "T-LW-101",
                titleEn = "Entry Fee: Lone Wolf Duel #101",
                titleBn = "এন্ট্রি ফি: লোন উলফ ডুয়েল #১০১",
                subtitleEn = "Deducted from wallet",
                subtitleBn = "ওয়ালেট থেকে কাটা হয়েছে"
            ),
            Transaction(
                id = "DEP-1001",
                userId = "P-101",
                type = TransactionType.ADD_MONEY,
                amount = 100,
                status = TransactionStatus.SUCCESS,
                timestamp = now - 86400000L,
                referenceId = "UTR492019482910",
                titleEn = "Added Cash via PhonePe UPI",
                titleBn = "PhonePe UPI দিয়ে টাকা যোগ",
                subtitleEn = "UTR: UTR492019482910 • Approved by Owner",
                subtitleBn = "ইউটিআর: UTR492019482910 • মালিক কর্তৃক অনুমোদিত"
            )
        )

        // Initial Withdrawal Requests
        _withdrawals.value = listOf(
            WithdrawalRequest(
                id = "WTH-1001",
                userId = "P-101",
                userName = "Subhajit Roy",
                freeFireUid = "2839104829",
                amount = 80,
                method = "UPI",
                payoutDestination = "subho@okhdfcbank",
                status = WithdrawalStatus.PAID,
                requestedAt = now - 86400000L
            ),
            WithdrawalRequest(
                id = "WTH-1002",
                userId = "P-201",
                userName = "Rahul Das",
                freeFireUid = "3829104812",
                amount = 120,
                method = "Paytm UPI",
                payoutDestination = "rahuldas@paytm",
                status = WithdrawalStatus.PENDING,
                requestedAt = now - 3600000L * 3
            )
        )

        // Initial Notifications
        _notifications.value = listOf(
            AppNotification(
                id = "NOTIF-1",
                titleEn = "Welcome to Battle Arena India!",
                titleBn = "ব্যাটেল এরিনায় স্বাগতম!",
                messageEn = "Free Fire Level 10+ is verified. Explore 1v1 Lone Wolf, 4v4 Clash Squad & 40P Battle Royale.",
                messageBn = "ফ্রি ফায়ার লেভেল ১০+ নিশ্চিত। ১v১ লোন উলফ, ৪v৪ ক্ল্যাশ স্কোয়াড ও ৪০ জন বিআর টুর্নামেন্টে অংশ নিন।",
                type = "GENERAL"
            ),
            AppNotification(
                id = "NOTIF-2",
                titleEn = "Room ID & Password Protection",
                titleBn = "রুম আইডি ও পাসওয়ার্ড সুরক্ষা",
                messageEn = "Room credentials unlock 15 minutes prior to match start strictly for registered players.",
                messageBn = "রুম ক্রেডেনশিয়াল ম্যাচ শুরুর ১৫ মিনিট আগে শুধুমাত্র রেজিস্টার্ড প্লেয়ারদের দেখানো হবে।",
                type = "ROOM"
            )
        )

        // Initial Leaderboard
        _leaderboard.value = listOf(
            LeaderboardEntry(1, "L-1", "Arijit Flame", "亗ARJ_KING亗", "1928374610", avatarId = 1, totalEarnings = 1450, totalKills = 112, matchesWon = 24),
            LeaderboardEntry(2, "L-2", "Sourav Hunter", "SOUS_SNIPER", "2839401928", avatarId = 2, totalEarnings = 1120, totalKills = 94, matchesWon = 19),
            LeaderboardEntry(3, "L-3", "Manik Hunter", "⚡MANIK_BOSS⚡", "2948109382", avatarId = 1, totalEarnings = 540, totalKills = 48, matchesWon = 12),
            LeaderboardEntry(4, "L-4", "Pratik Gamer", "PRATIK_OP", "3940192830", avatarId = 3, totalEarnings = 480, totalKills = 41, matchesWon = 8),
            LeaderboardEntry(5, "L-5", "Rupak Das", "RUPAK_YT", "4920194829", avatarId = 4, totalEarnings = 390, totalKills = 36, matchesWon = 7)
        )

        // Initial Match Results for Owner Verification & Payout Approval
        _matchResults.value = listOf(
            MatchResultRecord(
                id = "RES-BR-301-1",
                tournamentId = "T-BR-301",
                tournamentTitle = "Daily Mega Battle Royale #301",
                userId = "BA-70912",
                playerName = "Manik Hunter",
                freeFireUid = "2948109382",
                rank = 1,
                kills = 6,
                resultSummary = "Rank #1 (Booyah Champion)",
                placementPrize = 100,
                killPrize = 30,
                eligiblePrize = 130,
                isVerified = true,
                paymentStatus = PrizePaymentStatus.APPROVED,
                verifiedBy = BATTLE_ARENA_OWNER_EMAIL
            ),
            MatchResultRecord(
                id = "RES-BR-301-2",
                tournamentId = "T-BR-301",
                tournamentTitle = "Daily Mega Battle Royale #301",
                userId = "P-101",
                playerName = "Subhajit Roy",
                freeFireUid = "2839104829",
                rank = 2,
                kills = 4,
                resultSummary = "Rank #2",
                placementPrize = 70,
                killPrize = 25,
                eligiblePrize = 95,
                isVerified = true,
                paymentStatus = PrizePaymentStatus.PENDING_VERIFICATION,
                verifiedBy = BATTLE_ARENA_OWNER_EMAIL
            ),
            MatchResultRecord(
                id = "RES-BR-301-3",
                tournamentId = "T-BR-301",
                tournamentTitle = "Daily Mega Battle Royale #301",
                userId = "P-201",
                playerName = "Rahul Das",
                freeFireUid = "3829104812",
                rank = 3,
                kills = 3,
                resultSummary = "Rank #3",
                placementPrize = 50,
                killPrize = 20,
                eligiblePrize = 70,
                isVerified = false,
                paymentStatus = PrizePaymentStatus.PENDING_VERIFICATION
            ),
            MatchResultRecord(
                id = "RES-BR-301-4",
                tournamentId = "T-BR-301",
                tournamentTitle = "Daily Mega Battle Royale #301",
                userId = "P-301",
                playerName = "Arijit Flame",
                freeFireUid = "1928374610",
                rank = 4,
                kills = 2,
                resultSummary = "Rank #4",
                placementPrize = 50,
                killPrize = 20,
                eligiblePrize = 70,
                isVerified = false,
                paymentStatus = PrizePaymentStatus.PENDING_VERIFICATION
            ),
            MatchResultRecord(
                id = "RES-BR-301-5",
                tournamentId = "T-BR-301",
                tournamentTitle = "Daily Mega Battle Royale #301",
                userId = "P-401",
                playerName = "Sourav Hunter",
                freeFireUid = "2839401928",
                rank = 5,
                kills = 1,
                resultSummary = "Rank #5",
                placementPrize = 40,
                killPrize = 15,
                eligiblePrize = 55,
                isVerified = false,
                paymentStatus = PrizePaymentStatus.PENDING_VERIFICATION
            )
        )
    }
}
