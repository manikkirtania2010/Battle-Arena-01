package com.example.model

const val BATTLE_ARENA_OWNER_EMAIL = "kirtaniamanik2010@gmail.com"

enum class LevelVerificationStatus {
    UNVERIFIED,
    PENDING,
    VERIFIED,
    REJECTED
}

/**
 * User data class representing player profile and Firestore database collections.
 * Contains primary fields: uid, displayName, email, freeFireUID, walletBalance, referralCode.
 * Includes Free Fire level (must be Level 10+), level verification status, ban status, and owner verification.
 */
data class User(
    val uid: String = "",
    val displayName: String = "",
    val email: String = "",
    val freeFireUID: String = "",
    val freeFireName: String = "",
    val freeFireLevel: Int = 12, // Level 10+ required for tournament eligibility
    val levelVerificationStatus: LevelVerificationStatus = LevelVerificationStatus.VERIFIED,
    val walletBalance: Int = 0,
    val referralCode: String = "",
    val phone: String = "+91 98765 43210",
    val avatarId: Int = 1,
    val referredBy: String? = null,
    val totalKills: Int = 0,
    val totalWins: Int = 0,
    val totalEarnings: Int = 0,
    val totalTournaments: Int = 0,
    val isAdmin: Boolean = false,
    val isVerified: Boolean = true,
    val isBanned: Boolean = false,
    val banReason: String? = null
) {
    // Owner is strictly identified by the designated Super Admin email
    val isOwner: Boolean
        get() = email.trim().equals(BATTLE_ARENA_OWNER_EMAIL, ignoreCase = true)

    // Eligibility check: Player must be level 10 or above and not banned
    val isEligibleForTournament: Boolean
        get() = freeFireLevel >= 10 && !isBanned

    // Secondary constructor to maintain compatibility with legacy parameter names
    constructor(
        id: String,
        name: String,
        email: String,
        freeFireName: String = "",
        freeFireUid: String = "",
        freeFireLevel: Int = 12,
        walletBalance: Int = 0,
        phone: String = "+91 98765 43210",
        avatarId: Int = 1,
        referralCode: String = "",
        referredBy: String? = null,
        totalKills: Int = 0,
        totalWins: Int = 0,
        totalEarnings: Int = 0,
        totalTournaments: Int = 0,
        isAdmin: Boolean = false,
        isVerified: Boolean = true,
        isBanned: Boolean = false,
        banReason: String? = null
    ) : this(
        uid = id,
        displayName = name,
        email = email,
        freeFireUID = freeFireUid,
        freeFireName = freeFireName,
        freeFireLevel = freeFireLevel,
        levelVerificationStatus = if (freeFireLevel >= 10) LevelVerificationStatus.VERIFIED else LevelVerificationStatus.UNVERIFIED,
        walletBalance = walletBalance,
        referralCode = referralCode,
        phone = phone,
        avatarId = avatarId,
        referredBy = referredBy,
        totalKills = totalKills,
        totalWins = totalWins,
        totalEarnings = totalEarnings,
        totalTournaments = totalTournaments,
        isAdmin = email.trim().equals(BATTLE_ARENA_OWNER_EMAIL, ignoreCase = true) || isAdmin,
        isVerified = isVerified,
        isBanned = isBanned,
        banReason = banReason
    )

    // Backward-compatible property aliases
    val id: String get() = uid
    val name: String get() = displayName
    val freeFireUid: String get() = freeFireUID
}

data class LeaderboardEntry(
    val rank: Int,
    val userId: String,
    val name: String,
    val freeFireName: String,
    val freeFireUid: String,
    val avatarId: Int,
    val totalEarnings: Int,
    val totalKills: Int,
    val matchesWon: Int
)

enum class PaymentApprovalStatus {
    PENDING,
    APPROVED,
    REJECTED
}

data class AddMoneyRequest(
    val id: String,
    val userId: String,
    val userName: String,
    val freeFireUid: String,
    val amount: Int,
    val paymentMethod: String,
    val utrNumber: String,
    val screenshotNote: String = "Screenshot Uploaded",
    val status: PaymentApprovalStatus = PaymentApprovalStatus.PENDING,
    val requestedAt: Long = System.currentTimeMillis(),
    val rejectionReason: String? = null
)

data class AppNotification(
    val id: String,
    val titleEn: String,
    val titleBn: String,
    val messageEn: String,
    val messageBn: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isRead: Boolean = false,
    val type: String = "GENERAL"
)

data class IncidentReport(
    val id: String,
    val reportedUserId: String,
    val reportedUserName: String,
    val reportedUserUid: String,
    val tournamentId: String,
    val reason: String,
    val status: String = "INVESTIGATING", // "INVESTIGATING", "BANNED", "RESOLVED"
    val timestamp: Long = System.currentTimeMillis()
)
