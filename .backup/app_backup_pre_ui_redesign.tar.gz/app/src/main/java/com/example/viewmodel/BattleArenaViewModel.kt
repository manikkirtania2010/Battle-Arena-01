package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.BattleArenaRepository
import com.example.model.AddMoneyRequest
import com.example.model.AdminAuditLog
import com.example.model.AppLanguage
import com.example.model.AppNotification
import com.example.model.GameMode
import com.example.model.IncidentReport
import com.example.model.LeaderboardEntry
import com.example.model.MatchRefundItem
import com.example.model.PaymentApprovalStatus
import com.example.model.PlatformCommissionRecord
import com.example.model.Tournament
import com.example.model.TournamentStatus
import com.example.model.Transaction
import com.example.model.User
import com.example.model.Wallet
import com.example.model.WithdrawalRequest
import com.example.model.WithdrawalStatus
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class BattleArenaViewModel(
    val repository: BattleArenaRepository = BattleArenaRepository()
) : ViewModel() {

    val authRepository = repository.authRepository
    val currentLanguage: StateFlow<AppLanguage> = repository.currentLanguage
    val currentUser: StateFlow<User?> = repository.currentUser
    val currentWallet: StateFlow<Wallet> = repository.currentWallet
    val tournaments: StateFlow<List<Tournament>> = repository.tournaments
    val transactions: StateFlow<List<Transaction>> = repository.transactions
    val withdrawals: StateFlow<List<WithdrawalRequest>> = repository.withdrawals
    val addMoneyRequests: StateFlow<List<AddMoneyRequest>> = repository.addMoneyRequests
    val commissions: StateFlow<List<PlatformCommissionRecord>> = repository.commissions
    val leaderboard: StateFlow<List<LeaderboardEntry>> = repository.leaderboard
    val notifications: StateFlow<List<AppNotification>> = repository.notifications
    val incidentReports: StateFlow<List<IncidentReport>> = repository.incidentReports
    val refundRecords: StateFlow<List<MatchRefundItem>> = repository.refundRecords
    val adminAuditLogs: StateFlow<List<AdminAuditLog>> = repository.adminAuditLogs
    val adminWallet: StateFlow<com.example.model.AdminWallet> = repository.adminWallet
    val adminWithdrawals: StateFlow<List<com.example.model.AdminWithdrawalRecord>> = repository.adminWithdrawals
    val adminLedger: StateFlow<List<com.example.model.AdminLedgerEntry>> = repository.adminLedger
    val matchResults: StateFlow<List<com.example.model.MatchResultRecord>> = repository.matchResults

    private val _showNotifications = MutableStateFlow(false)
    val showNotifications: StateFlow<Boolean> = _showNotifications.asStateFlow()

    fun setShowNotifications(show: Boolean) {
        _showNotifications.value = show
    }

    private val _selectedTab = MutableStateFlow(0)
    val selectedTab: StateFlow<Int> = _selectedTab.asStateFlow()

    private val _selectedModeFilter = MutableStateFlow<GameMode?>(null)
    val selectedModeFilter: StateFlow<GameMode?> = _selectedModeFilter.asStateFlow()

    private val _selectedStatusFilter = MutableStateFlow<TournamentStatus?>(null)
    val selectedStatusFilter: StateFlow<TournamentStatus?> = _selectedStatusFilter.asStateFlow()

    private val _selectedTournament = MutableStateFlow<Tournament?>(null)
    val selectedTournament: StateFlow<Tournament?> = _selectedTournament.asStateFlow()

    private val _showAddMoney = MutableStateFlow(false)
    val showAddMoney: StateFlow<Boolean> = _showAddMoney.asStateFlow()

    private val _showWithdraw = MutableStateFlow(false)
    val showWithdraw: StateFlow<Boolean> = _showWithdraw.asStateFlow()

    private val _showReferModal = MutableStateFlow(false)
    val showReferModal: StateFlow<Boolean> = _showReferModal.asStateFlow()

    private val _showCreateTournament = MutableStateFlow(false)
    val showCreateTournament: StateFlow<Boolean> = _showCreateTournament.asStateFlow()

    private val _showAuthDialog = MutableStateFlow(false)
    val showAuthDialog: StateFlow<Boolean> = _showAuthDialog.asStateFlow()

    private val _verifyingTournament = MutableStateFlow<Tournament?>(null)
    val verifyingTournament: StateFlow<Tournament?> = _verifyingTournament.asStateFlow()

    private val _userFeedback = MutableStateFlow<String?>(null)
    val userFeedback: StateFlow<String?> = _userFeedback.asStateFlow()

    // Filtered tournaments flow
    val filteredTournaments: StateFlow<List<Tournament>> = combine(
        tournaments,
        selectedModeFilter,
        selectedStatusFilter
    ) { list, mode, status ->
        list.filter { t ->
            val matchMode = (mode == null || t.mode == mode)
            val matchStatus = (status == null || t.status == status)
            matchMode && matchStatus
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun selectTab(index: Int) {
        _selectedTab.value = index
    }

    fun selectModeFilter(mode: GameMode?) {
        _selectedModeFilter.value = mode
    }

    fun selectStatusFilter(status: TournamentStatus?) {
        _selectedStatusFilter.value = status
    }

    fun openTournamentDetails(tournament: Tournament) {
        _selectedTournament.value = tournament
    }

    fun closeTournamentDetails() {
        _selectedTournament.value = null
    }

    fun setShowAddMoney(show: Boolean) {
        _showAddMoney.value = show
    }

    fun setShowWithdraw(show: Boolean) {
        _showWithdraw.value = show
    }

    fun setShowReferModal(show: Boolean) {
        _showReferModal.value = show
    }

    fun setShowCreateTournament(show: Boolean) {
        _showCreateTournament.value = show
    }

    fun setShowAuthDialog(show: Boolean) {
        _showAuthDialog.value = show
    }

    fun onAuthSuccess(user: User) {
        repository.setCurrentUser(user)
        _userFeedback.value = "Welcome, ${user.name}! Logged in successfully."
    }

    fun signOut() {
        repository.signOut()
        _userFeedback.value = "Logged out successfully."
    }

    fun openVerifyTournament(tournament: Tournament?) {
        _verifyingTournament.value = tournament
    }

    fun clearFeedback() {
        _userFeedback.value = null
    }

    fun toggleLanguage() {
        repository.toggleLanguage()
    }

    fun toggleAdminMode() {
        repository.toggleAdminMode()
        val isAdmin = repository.currentUser.value?.isAdmin == true
        _userFeedback.value = if (isAdmin) "Admin Mode Activated" else "Admin Mode Deactivated"
    }

    fun updateProfile(name: String, ffName: String, ffUid: String, phone: String, avatarId: Int) {
        repository.updateProfile(name, ffName, ffUid, phone, avatarId)
        _userFeedback.value = "Profile updated successfully!"
    }

    fun addMoney(amount: Int, method: String) {
        val success = repository.addMoney(amount, method)
        if (success) {
            _showAddMoney.value = false
            _userFeedback.value = "₹$amount successfully added to your wallet!"
        }
    }

    fun requestWithdrawal(amount: Int, method: String, destination: String) {
        val (success, message) = repository.requestWithdrawal(amount, method, destination)
        _userFeedback.value = message
        if (success) {
            _showWithdraw.value = false
        }
    }

    fun applyReferralCode(code: String) {
        val (success, message) = repository.applyReferralCode(code)
        _userFeedback.value = message
        if (success) {
            _showReferModal.value = false
        }
    }

    fun joinTournament(tournamentId: String) {
        val (success, message) = repository.joinTournament(tournamentId)
        _userFeedback.value = message
        // Keep selected tournament in sync
        _selectedTournament.value = repository.tournaments.value.find { it.id == tournamentId }
    }

    fun createTournament(
        titleEn: String,
        titleBn: String,
        mode: GameMode,
        entryFee: Int,
        startTime: String,
        map: String
    ) {
        val t = repository.createTournament(titleEn, titleBn, mode, entryFee, startTime, map)
        _showCreateTournament.value = false
        _userFeedback.value = "Tournament ${t.titleEn} created successfully!"
    }

    fun updateRoomCredentials(tournamentId: String, roomId: String, roomPass: String) {
        repository.updateRoomCredentials(tournamentId, roomId, roomPass)
        _userFeedback.value = "Room ID & Password updated for match!"
    }

    fun verifyLoneWolf(tournamentId: String, winnerId: String) {
        repository.verifyAndDistributeLoneWolf(tournamentId, winnerId)
        _verifyingTournament.value = null
        _userFeedback.value = "Result verified! Prize ₹40 credited to winner. Commission ₹10 recorded."
        _selectedTournament.value = repository.tournaments.value.find { it.id == tournamentId }
    }

    fun verifyClashSquad(tournamentId: String, winningTeam: String) {
        repository.verifyAndDistributeClashSquad(tournamentId, winningTeam)
        _verifyingTournament.value = null
        _userFeedback.value = "Clash Squad verified! Prize ₹120 credited to $winningTeam. Commission ₹40 recorded."
        _selectedTournament.value = repository.tournaments.value.find { it.id == tournamentId }
    }

    fun verifyBattleRoyale(tournamentId: String) {
        repository.verifyAndDistributeBattleRoyale(tournamentId)
        _verifyingTournament.value = null
        _userFeedback.value = "BR verified! Placement ₹460 + Kills ₹110 distributed. Commission ₹230 recorded."
        _selectedTournament.value = repository.tournaments.value.find { it.id == tournamentId }
    }

    fun updateWithdrawalStatus(requestId: String, newStatus: WithdrawalStatus, reason: String? = null) {
        val (ok, message) = repository.updateWithdrawalStatus(requestId, newStatus, reason)
        _userFeedback.value = message
    }

    fun approveWithdrawal(requestId: String) {
        val (ok, message) = repository.approveWithdrawal(requestId)
        _userFeedback.value = message
    }

    fun markWithdrawalPaid(requestId: String, paymentUtr: String) {
        val (ok, message) = repository.markWithdrawalPaid(requestId, paymentUtr)
        _userFeedback.value = message
    }

    fun rejectWithdrawal(requestId: String, reason: String) {
        val (ok, message) = repository.rejectWithdrawal(requestId, reason)
        _userFeedback.value = message
    }

    fun failWithdrawal(requestId: String, reason: String) {
        val (ok, message) = repository.failWithdrawal(requestId, reason)
        _userFeedback.value = message
    }

    fun submitAddMoneyRequest(
        amount: Int,
        paymentMethod: String,
        utrNumber: String,
        screenshotNote: String = "Screenshot Submitted"
    ) {
        val (success, message) = repository.submitAddMoneyRequest(amount, paymentMethod, utrNumber, screenshotNote)
        _userFeedback.value = message
        if (success) {
            _showAddMoney.value = false
        }
    }

    fun approveAddMoneyRequest(requestId: String) {
        val (success, message) = repository.approveAddMoneyRequest(requestId)
        _userFeedback.value = message
    }

    fun rejectAddMoneyRequest(requestId: String, reason: String) {
        val (success, message) = repository.rejectAddMoneyRequest(requestId, reason)
        _userFeedback.value = message
    }

    fun submitLevelVerification(level: Int, note: String = "ID Proof Uploaded") {
        val (success, message) = repository.submitLevelVerification(level, note)
        _userFeedback.value = message
    }

    fun banPlayer(userId: String, reason: String) {
        val (_, message) = repository.banPlayer(userId, reason)
        _userFeedback.value = message
    }

    fun unbanPlayer(userId: String) {
        val (_, message) = repository.unbanPlayer(userId)
        _userFeedback.value = message
    }

    fun markNotificationRead(id: String) {
        repository.markNotificationRead(id)
    }

    fun tickCountdowns() {
        repository.tickCountdowns()
    }

    fun cancelLoneWolfWaitingPlayer(tournamentId: String, refundFee: Boolean = true) {
        val (_, message) = repository.cancelLoneWolfWaitingPlayer(tournamentId, refundFee)
        _userFeedback.value = message
        _selectedTournament.value = repository.tournaments.value.find { it.id == tournamentId }
    }

    fun updateBattleRoyaleSchedule(tournamentId: String, newScheduledTime: String) {
        val (_, message) = repository.updateBattleRoyaleSchedule(tournamentId, newScheduledTime)
        _userFeedback.value = message
        _selectedTournament.value = repository.tournaments.value.find { it.id == tournamentId }
    }

    fun markTournamentUnsuccessful(tournamentId: String, reason: String = "Technical or matchmaking failure") {
        val (_, message) = repository.markTournamentUnsuccessful(tournamentId, reason)
        _userFeedback.value = message
        _selectedTournament.value = repository.tournaments.value.find { it.id == tournamentId }
    }

    fun approveAndProcessMatchRefund(tournamentId: String, refundItemId: String? = null) {
        val (_, message) = repository.approveAndProcessMatchRefund(tournamentId, refundItemId)
        _userFeedback.value = message
        _selectedTournament.value = repository.tournaments.value.find { it.id == tournamentId }
    }

    fun requestAdminUPIWithdrawal(amount: Int, upiId: String, autoProcessSuccess: Boolean = true) {
        val (_, message) = repository.requestAdminUPIWithdrawal(amount, upiId, autoProcessSuccess)
        _userFeedback.value = message
    }

    fun saveOwnerVerifiedUpiId(newUpiId: String) {
        val (_, message) = repository.saveOwnerVerifiedUpiId(newUpiId)
        _userFeedback.value = message
    }

    fun failAdminWithdrawal(withdrawalId: String, reason: String = "Declined by Payment Provider") {
        val (_, message) = repository.failAdminWithdrawal(withdrawalId, reason)
        _userFeedback.value = message
    }

    fun reverseAdminWithdrawal(withdrawalId: String, reason: String = "Settlement reversal") {
        val (_, message) = repository.reverseAdminWithdrawal(withdrawalId, reason)
        _userFeedback.value = message
    }

    fun updateBrPrizeChart(tournamentId: String, newTiers: List<com.example.model.BrPrizeTier>, killPrize: Int = 110) {
        val (_, message) = repository.updateBrPrizeChart(tournamentId, newTiers, killPrize)
        _userFeedback.value = message
        _selectedTournament.value = repository.tournaments.value.find { it.id == tournamentId }
    }

    fun verifyMatchResult(resultId: String, verifiedRank: Int? = null, verifiedKills: Int? = null, isApproved: Boolean = true) {
        val (_, message) = repository.verifyMatchResult(resultId, verifiedRank, verifiedKills, isApproved)
        _userFeedback.value = message
    }

    fun approvePrizePayment(resultId: String) {
        val (_, message) = repository.approveAndProcessPrizePayment(resultId)
        _userFeedback.value = message
    }

    fun updateTournamentSettings(tournamentId: String, scheduledTime: String?, entryFee: Int?, totalSlots: Int?, mapName: String?) {
        val (_, message) = repository.updateBattleRoyaleSchedule(
            tournamentId = tournamentId,
            newScheduledTime = scheduledTime ?: "08:00 PM IST",
            entryFee = entryFee,
            totalSlots = totalSlots,
            mapName = mapName
        )
        _userFeedback.value = message
        _selectedTournament.value = repository.tournaments.value.find { it.id == tournamentId }
    }

    fun verifyRoomPlayer(
        tournamentId: String,
        freeFireUid: String,
        newStatus: com.example.model.PlayerVerificationStatus,
        notes: String? = null
    ) {
        val (_, message) = repository.verifyRoomPlayer(tournamentId, freeFireUid, newStatus, notes)
        _userFeedback.value = message
        _selectedTournament.value = repository.tournaments.value.find { it.id == tournamentId }
    }

    fun removeUnauthorizedPlayer(
        tournamentId: String,
        freeFireUid: String,
        reason: String,
        shouldRefund: Boolean = false
    ) {
        val (_, message) = repository.removeUnauthorizedPlayer(tournamentId, freeFireUid, reason, shouldRefund)
        _userFeedback.value = message
        _selectedTournament.value = repository.tournaments.value.find { it.id == tournamentId }
    }

    fun auditRoomRoster(
        tournamentId: String,
        roomPlayerUids: List<String>
    ): com.example.model.RoomRosterAuditReport {
        return repository.auditRoomRoster(tournamentId, roomPlayerUids)
    }
}

