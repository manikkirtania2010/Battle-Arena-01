package com.example.data

import android.util.Log
import com.example.model.Tournament
import com.example.model.User
import com.example.model.Wallet
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await

/**
 * Manages Firestore database operations for collections:
 * - 'users' (structured with uid, displayName, email, freeFireUID, walletBalance, referralCode)
 * - 'tournaments'
 * - 'wallets'
 */
class FirestoreManager {

    private val firestore: FirebaseFirestore? by lazy {
        try {
            FirebaseFirestore.getInstance()
        } catch (e: Exception) {
            Log.w("FirestoreManager", "Firestore not initialized (google-services.json missing or offline mode)", e)
            null
        }
    }

    suspend fun saveUser(user: User): Boolean {
        return try {
            firestore?.collection("users")
                ?.document(user.uid)
                ?.set(user)
                ?.await()
            true
        } catch (e: Exception) {
            Log.e("FirestoreManager", "Failed to save user to Firestore", e)
            false
        }
    }

    suspend fun getUser(uid: String): User? {
        return try {
            firestore?.collection("users")
                ?.document(uid)
                ?.get()
                ?.await()
                ?.toObject(User::class.java)
        } catch (e: Exception) {
            Log.e("FirestoreManager", "Failed to get user from Firestore", e)
            null
        }
    }

    suspend fun saveTournament(tournament: Tournament): Boolean {
        return try {
            firestore?.collection("tournaments")
                ?.document(tournament.id)
                ?.set(tournament)
                ?.await()
            true
        } catch (e: Exception) {
            Log.e("FirestoreManager", "Failed to save tournament to Firestore", e)
            false
        }
    }

    suspend fun syncWallet(wallet: Wallet): Boolean {
        return try {
            firestore?.collection("wallets")
                ?.document(wallet.userId)
                ?.set(wallet)
                ?.await()
            true
        } catch (e: Exception) {
            Log.e("FirestoreManager", "Failed to sync wallet to Firestore", e)
            false
        }
    }
}
